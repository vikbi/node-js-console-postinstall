CREATE TABLE `orders` (
  `id` bigint(11) NOT NULL,
  `exchange` varchar(60) NOT NULL,
  `symbol` varchar(60) NOT NULL,
  `quantity` int(10) NOT NULL,
  `ltp` float NOT NULL,
  `order_type` varchar(60) NOT NULL,
  `order_status` tinyint(4) NOT NULL DEFAULT 0,
  `place_at` datetime NOT NULL,
  `last_sent` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;