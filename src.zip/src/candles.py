from datetime import datetime, timedelta

from src import DATE_FORMAT, utils

__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"


class Resolution:
    MONTHLY, WEEKLY, DAILY, ANNUAL, HOURLY = "1Mo", "1W", "1D", "1Y", "1h"
    MIN_30, MIN_15, MIN_10, MIN_5, MIN_3, MIN_2, MIN_1 = "30m", "15m", "10m", "5m", "3m", "2m", "1m"


class Pattern:
    BULLISH, BEARISH = "bullish", "bearish"
    OL, OH = 'OL', 'OH'


class Indecision:
    BULLISH, BEARISH, BALANCED, INVALID = 'bullish', 'bearish', 'balanced', 'Invalid'


class Candle:
    class Color:
        RED = 'r'
        GREEN = 'g'
        NONE = '0'

    def __init__(self, open, high, low, close, volume=0, resolution=Resolution.MIN_5, dt=None):
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume
        self.datetime = dt or datetime.now()
        self.resolution = resolution

    def __contains__(self, item):
        if isinstance(item, datetime) and isinstance(self.datetime, datetime):
            return self.datetime <= item <= self.get_end_time()
        elif isinstance(item, float) or isinstance(item, int):
            return self.low <= item <= self.high
        return False

    def __eq__(self, other):
        return isinstance(other, type(self)) and self.datetime == other.datetime and self.resolution == other.resolution

    def to_dict(self):
        return dict(datetime=self.datetime,
                    open=self.open,
                    high=self.high,
                    low=self.low,
                    close=self.close,
                    volume=self.volume)

    def get_end_time(self):
        return self.datetime + timedelta(minutes=get_step_minutes(self.resolution))

    def get_start_time(self):
        return self.datetime

    def diff(self):
        return utils.parse_float(100 * (self.close / self.open - 1), precision=2)

    def hldiff(self):
        if self.trend() == 'g':
            return 100 * (self.high / self.low - 1)
        elif self.trend() == 'r':
            return 100 * abs(self.low / self.high - 1)
        else:
            return 100 * (self.high / self.low - 1)

    def range(self):
        return self.high - self.low

    def avg_price(self):
        return (self.high + self.low + self.close) / 3.0

    def trend(self):
        return 'g' if self.open < self.close else 'r' if self.open > self.close else '0'

    def color(self):
        return Candle.Color.GREEN if self.open < self.close else Candle.Color.RED if self.open > self.close else Candle.Color.NONE

    def update_hlcv(self, h, l, c, v=0):
        self.high = h if h > self.high else self.high
        self.low = l if l < self.low else self.low
        self.close = c
        self.volume += v

    def update_hlc_by_candle(self, candle):
        self.update_hlcv(candle.high, candle.low, candle.close, candle.volume)

    def __str__(self):
        return "o: {}, h: {}, l: {}, c: {}, v: {} {}, {}" \
            .format(self.open, self.high, self.low, self.close, self.volume, self.resolution, self.datetime, )

    def __repr__(self):
        return self.__str__()


class CandleJsonEncoder(utils.DateTimeEncoder):
    def default(self, obj):
        if isinstance(obj, Candle):
            encoded_object = obj.__dict__
        else:
            encoded_object = utils.DateTimeEncoder.default(self, obj)
        return encoded_object


class Quote:
    def __init__(self, open, high, low, close, ltp):
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.ltp = ltp


REFERENCE_WEEK_START_DATE = datetime.strptime("2014-01-06", DATE_FORMAT)
MARKET_START_TIME = datetime.now().replace(hour=9, minute=15, second=0)
MARKET_END_TIME = datetime.now().replace(hour=15, minute=30, second=0)


def get_market_start_end_datetime(dt):
    pass


def get_step_minutes(resolution):
    if resolution == Resolution.HOURLY:
        return 30
    elif resolution == Resolution.MIN_30:
        return 30
    elif resolution == Resolution.MIN_15:
        return 15
    elif resolution == Resolution.MIN_10:
        return 10
    elif resolution == Resolution.MIN_5:
        return 5
    elif resolution == Resolution.MIN_3:
        return 3
    elif resolution == Resolution.MIN_2:
        return 2
    elif resolution == Resolution.MIN_1:
        return 1
    elif resolution == Resolution.DAILY:
        return 375


if __name__ == "__main__":
    pass
