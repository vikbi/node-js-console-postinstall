from src import constants

class AppInfo:
    def __init__(self, api_key, api_secret, broker, redirect_uri='', is_default=False):
        # type: (str, str, str, str) -> object
        self.api_key, self.api_secret, self.broker, self.is_default = api_key, api_secret, broker, is_default
        self.redirect_uri = redirect_uri
        # def get_api_key(self):
        #     return self.__api_key
        #
        # def get_api_secret(self):
        #     return self.api_secret
        #
        # def is_default(self):
        #     return self.is_default


class User:
    def __init__(self, client, broker, telegram):
        if broker not in constants.Broker.__dict__:
            raise NotImplementedError('Either broker "{}" is misspelled or not supported!'.format(broker))

        self.client = client
        self.broker = broker
        self.telegram = telegram
        self.app_info = None

    def set_app_info(self, app_info):
        self.app_info = app_info

    def get_app_info(self):
        # type: () -> AppInfo
        if self.app_info is None:
            raise ValueError("app info not set!")
        return self.app_info
