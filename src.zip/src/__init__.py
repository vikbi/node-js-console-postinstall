import os
import time
os.environ['TZ'] = 'Asia/Kolkata'
DATE_FORMAT = '%Y-%m-%d'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
DEFAULT_DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S.%f'
TIME_FORMAT = '%H:%M:%S'
TODAY = time.strftime(DATE_FORMAT)
BASE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__)))

BUY, SELL = 'buy', 'sell'
ORPHANED = 'orphaned'


def get_path(path):
    return os.path.abspath(os.path.join(BASE_PATH, path))


def join_path(path, *paths):
    return os.path.join(path, *paths)


def auto_str(cls):
    def __str__(self):
        return '%s(%s)' % (
            type(self).__name__,
            ', '.join('%s=%s' % item for item in vars(self).items())
        )

    cls.__str__ = __str__
    return cls


if __name__ == '__main__':
    a = join_path("/var/log/algotrades", "a.log")
    print(a)
