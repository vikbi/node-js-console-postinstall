-- Id	open	high	low	close	last_trade_time	data feed time	PSAR	TREND	EP	ACC	K = (EP-PSAR)*ACC	CURRENT_SAR = PSAR + K
CREATE TABLE IF NOT EXISTS `data_{exchange}_{symbol}_{timeframe}` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `open` decimal(10,2) NOT NULL,
  `high` decimal(10,2) NOT NULL,
  `low` decimal(10,2) NOT NULL,
  `close` decimal(10,2) NOT NULL,
  `dt` timestamp NOT NULL,
  `psar` decimal(10,2) DEFAULT NULL,
  `trend` tinyint(1) DEFAULT NULL,
  `ep` decimal(10,2) DEFAULT NULL,
  `acc` decimal(7,2),
  `k` decimal(7,2),
  `current_psar` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

