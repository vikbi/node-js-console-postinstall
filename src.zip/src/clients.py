from kiteconnect import KiteConnect, KiteTicker
from kiteconnect.exceptions import TokenException, InputException

from src._logger import *
from src import creds, config, mysqlDatastore, constants
from src.brokers import factory as broker_factory

__db_index = 2  # TODO Can go to config


class ClientNotProvisionedError(StandardError):
    """Raised when the client is not provisioned to use the services!"""
    pass


class InvalidSession(StandardError):
    """Raised when the client is access_token is expired!"""
    pass


def get_clients():
    # type: () -> dict
    # _clients = {}
    # for api_key, app_config in creds.api_key_map.iteritems():
    #     for client_id in app_config.get('users', set()):
    #         _clients[client_id] = creds.AppInfo(api_key, app_config.get('secret', ''), True)
    return creds.app_details


def get_user(client_id):
    user = creds.user_details.get(client_id, None)
    if user is None:
        raise ClientNotProvisionedError
    app_info = creds.app_details.get(client_id, None)
    if app_info is None:
        raise ClientNotProvisionedError

    user.set_app_info(app_info)
    return user


def is_client_provisioned(client_id):
    return client_id in creds.user_details


def get_api_key(client_id):
    # type: (str) -> str
    return get_user(client_id).get_app_info().api_key


def __get_api_secret(client_id):
    # type: (str) -> str
    return get_user(client_id).get_app_info().api_key


__client_kites = {}
__client_kws = {}


def get_client_kite(client_id, validate_kite_session=False):
    # type: (str) -> KiteConnect
    if __client_kites.get(client_id, None) is None:
        __client_kites[client_id] = KiteConnect(api_key=get_api_key(client_id))
    access_token = __get_token(client_id)
    __client_kites[client_id].set_access_token(access_token)
    if validate_kite_session:
        __client_kites[client_id].profile()  # validate the existing access_token
    return __client_kites[client_id]


def get_default_client_kite():
    # type: () -> KiteConnect
    kite_clients = filter(lambda c_id: get_clients().get(c_id).broker == constants.Broker.KITE, get_clients().keys())
    default_clients_list = filter(lambda c_id: get_clients().get(c_id).is_default, kite_clients)
    client_list = default_clients_list + kite_clients

    for client_id in client_list:
        try:
            # return anyone who has a valid access token, preferably default marked,
            # meaning one who has authorised itself today
            return get_client_kite(client_id, True)
        except (TokenException, InputException):
            pass

    raise ValueError('No client provisioned or Invalid access_token for each of the client.')


def get_client_kws(client_id, validate_kite_session=False):
    # type: (str, bool) -> KiteTicker

    """
    This always return a new instance of KiteTicker. Onus of managing and destroying the KiteTicker object is on the user
    :param client_id:
    :param validate_kite_session:
    :return:
    """
    if validate_kite_session:
        get_client_kite(client_id, validate_kite_session)  # to validate the existing access_token

    return KiteTicker(get_api_key(client_id), __get_token(client_id))


def get_default_client_kws():
    kite_clients = filter(lambda c_id: get_clients().get(c_id).broker == constants.Broker.KITE, get_clients().keys())
    default_clients_list = filter(lambda c_id: get_clients().get(c_id).is_default, kite_clients)
    client_list = default_clients_list + kite_clients

    for client_id in client_list:
        try:
            # return anyone who has a valid access token, preferably default marked,
            # meaning one who has authorised itself today
            return get_client_kws(client_id, True)
        except (TokenException, InputException):
            pass

    raise ValueError('No client provisioned or Invalid access_token for each of the client.')


def generate_access_token_from_req_token(request_token, client_id):
    """
    Generates access_token using request_token
    """
    user = get_user(client_id)
    user_broker = broker_factory.get_broker_by_name(user.broker, client_id)
    access_token = user_broker.generate_access_token_from_req_token(user.get_app_info().api_key,
                                                                    user.get_app_info().api_secret, request_token,
                                                                    user.get_app_info().redirect_uri)

    user_broker.configure_session(user.get_app_info().api_key, access_token)

    log_debug("New access_token generated for {}".format(user_broker.client_id))

    __store_token(user_broker.client_id, access_token)

    log_debug("New access_token persisted for {}".format(user_broker.client_id))

    log_debug('User data: {}'.format(user_broker.get_profile()))
    return user_broker.get_profile()


def __store_token(client_id, access_token):
    mysqlDatastore.save_access_token(client_id, access_token)


def __get_token(client_id):
    return mysqlDatastore.get_access_token(client_id)


def get_login_url(client_id):
    user = get_user(client_id)
    user_broker = broker_factory.get_broker_by_name(user.broker, client_id)
    return user_broker.get_login_url(user.get_app_info().api_key, user.get_app_info().redirect_uri)


def get_profile(client_id):
    user = get_user(client_id)
    user_broker = broker_factory.get_broker_by_name(user.broker, client_id)
    user_broker.configure_session(user.get_app_info().api_key, __get_token(client_id))
    return get_client_kite(client_id).profile()


def get_telegram(client_id):
    user = get_user(client_id)
    return user.telegram if user else config.TELEGRAM_CHANNEL_CHAT_ID


def get_a_valid_session(broker=None):
    try:
        client_list = creds.user_details.values()
        if broker:
            client_list = filter(lambda c: c.broker == broker, client_list)

        # bringing default accounts on top of the list
        last_default_idx = 0
        for i in range(len(client_list)):
            c = client_list[i]
            if creds.app_details.get(c.client).is_default:  # swap
                temp = client_list[last_default_idx]
                client_list[last_default_idx] = client_list[i]
                client_list[i] = temp
                last_default_idx += 1

        for c in client_list:
            try:
                user_app = creds.app_details.get(c.client)
                user_broker = broker_factory.get_broker_by_name(c.broker, c.client)
                access_token = __get_token(c.client)
                session = user_broker.generate_session_by_access_token(user_app.api_key, access_token)
                user_broker.configure(session)
                if user_broker.is_session_valid():
                    return c, session
            except:
                log_exception("IGNORE: error while getting a valid session.")
    except Exception as e:
        raise ValueError("Error getting a valid session.", e)

    raise ValueError('No client provisioned or Invalid access_token for each of the client.')
    # return None, None


def get_session(client_id):
    user = creds.user_details.get(client_id, None)
    if user:
        user_app = creds.app_details.get(user.client)
        user_broker = broker_factory.get_broker_by_name(user.broker, user.client)
        access_token = __get_token(client_id)
        session = user_broker.generate_session_by_access_token(user_app.api_key, access_token)
        user_broker.configure(session)
        if user_broker.is_session_valid():
            return user, session

    return None, None


def get_broker(client_id):
    user = get_user(client_id)
    user_broker = broker_factory.get_broker_by_name(user.broker, client_id)
    access_token = __get_token(client_id)
    try:
        user_broker.configure_session(user.get_app_info().api_key, access_token)
    except Exception as e:
        raise InvalidSession(e)

    return user_broker
