import os
import sys

from pymysql.connections import Connection

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
from src.config import MYSQL_CONFIG
from src.models import *
from src import utils
from src._logger2 import *

def get_connection():
    return Connection(host=MYSQL_CONFIG.HOST,
                      user=MYSQL_CONFIG.USER,
                      password=MYSQL_CONFIG.PASSWORD,
                      database=MYSQL_CONFIG.DATABASE,
                      port=MYSQL_CONFIG.PORT,
                      unix_socket=MYSQL_CONFIG.UNIX_SOCKET)


def get_connection_without_db():
    return Connection(host=MYSQL_CONFIG.HOST,
                      user=MYSQL_CONFIG.USER,
                      password=MYSQL_CONFIG.PASSWORD,
                      database=None,
                      port=MYSQL_CONFIG.PORT,
                      unix_socket=MYSQL_CONFIG.UNIX_SOCKET)


def get_sql_from_file(filepath):
    """
    Get the SQL instruction from a file

    :return: a list of each SQL query
    """
    from os import path
    SEMICOLON = ';'
    # File did not exists
    if path.isfile(filepath) is False:
        raise ValueError("File load error : {}".format(filepath))
    else:
        with open(filepath, "r") as sql_file:
            # Split file in list
            for ret in sql_file.read().split(SEMICOLON):
                query = ret.strip()
                if query:
                    yield query + SEMICOLON


def ensure_db():
    """
    call create db/tables
    """
    connection = get_connection_without_db()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_DB_FILENAME)):
                result = cursor.execute(query.format(db_name=MYSQL_CONFIG.DATABASE))
                log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()


def ensure_data_table(exchange, symbol, timeframe):
    """
    call create table for symbol/timeframe
    """
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_DATA_TABLE_FILENAME)):
                query = query.format(exchange=exchange, symbol=symbol, timeframe=timeframe)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
                cursor.fetchall()
        connection.commit()
    finally:
        connection.close()


def ensure_ltp_table(exchange, symbol):
    """
        call create table for symbol' ltp
        """
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_LTP_TABLE_FILENAME)):
                query = query.format(exchange=exchange, symbol=symbol)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()


def ensure_bsq_data_table(exchange, symbol):
    """
    call create table for symbol
    """
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_BSQ_DATA_TABLE_FILENAME)):
                query = query.format(exchange=exchange, symbol=symbol)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
                cursor.fetchall()
        connection.commit()
    finally:
        connection.close()

def ensure_trade_table(exchange, symbol):
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_TRADE_TABLE_FILENAME)):
                query = query.format(exchange=exchange, symbol=symbol)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()

def ensure_trade_config_table(exchange, symbol):
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_TRADE_CONFIG_TABLE_FILENAME)):
                query = query.format(exchange=exchange, symbol=symbol)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()

def ensure_orders_table(exchange, symbol):
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            for query in get_sql_from_file(get_path(MYSQL_CONFIG.CREATE_TEMPLATE_FOR_ORDER_TABLE_FILENAME)):
                # query = query.format(exchange=exchange, symbol=symbol)
                result = cursor.execute(query)
                log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()


def get_symbols():
    # type: () -> list[Symbol]
    """
    get symbols for subscribtion
    """
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `symbols` where enabled=1;"
            cursor.execute(query)
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [Symbol(*row) for row in result]


def get_access_token(client_id):
    # type: (str) -> str

    """
    get access token for the client
    """
    connection = get_connection()
    result = None
    try:
        with connection.cursor() as cursor:
            query = "select * from `broker_token` where client_id=%s;"
            cursor.execute(query, (client_id,))
            result = cursor.fetchone()
            log_debug("{} :{}".format(query, len(result) if result else 0))
    finally:
        connection.close()
    return result[1] if result else ''


def save_access_token(client_id, access_token):
    # type: (str) -> str

    """
    get access token for the client
    """
    connection = get_connection()
    result = None
    try:
        with connection.cursor() as cursor:
            query = "update `broker_token` set access_token=%s where client_id=%s;"
            result = cursor.execute(query, (access_token, client_id))
            log_debug("{} :{}".format(query, result))
            if result is 0:
                query = "insert into `broker_token` (`client_id`, `access_token`) values (%s, %s);"
                result = cursor.execute(query, (client_id, access_token))

        connection.commit()
    finally:
        connection.close()
    return True if result else False


def get_psar_settings(enabled=1):
    # type: (int) -> list[PsarSetting]
    """
    get psar settings
    """
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `psar_settings` where enabled=%s;"
            cursor.execute(query, (enabled,))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [PsarSetting(*row) for row in result]


def save_psar_setting(psar_setting):
    # type: (PsarSetting) -> int
    connection = get_connection()
    result = 0
    try:
        with connection.cursor() as cursor:
            query = "insert into `psar_settings` " \
                    "(title, exchange, symbol, timeframe, min_acc, max_acc, acc, dacc, enabled) " \
                    "values (%s, %s, %s, %s, %s, %s, %s, %s, %s);"
            result = cursor.execute(query,
                                    (psar_setting.title,
                                     psar_setting.exchange,
                                     psar_setting.symbol,
                                     psar_setting.timeframe,
                                     psar_setting.min_acc,
                                     psar_setting.max_acc,
                                     psar_setting.acc,
                                     psar_setting.dacc,
                                     psar_setting.enabled))

            log_debug("{} :{}".format(query, result))

        connection.commit()
    finally:
        connection.close()
    return result


def get_psar_data(exchange, symbol, timeframe, limit=4):
    table_name = MYSQL_CONFIG.PSAR_DATA_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol, timeframe=timeframe)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` order by `id` desc limit %s;"
            cursor.execute(query, (limit,))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [PsarData(*row) for row in result]

def get_psar_data_from(exchange, symbol, timeframe, start_time, end_time):
    table_name = MYSQL_CONFIG.PSAR_DATA_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol, timeframe=timeframe)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` where created_at between %s and %s order by `id` desc;"
            cursor.execute(query, (start_time, end_time))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [PsarData(*row) for row in result]


def get_ltp_data(exchange, symbol, limit=90):
    table_name = MYSQL_CONFIG.LTP_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` order by `id` desc limit %s;"
            cursor.execute(query, (limit,))
            result = cursor.fetchall()
             
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [LtpData(*row) for row in result]

def save_order_data(order_data):
    table_name = "orders"
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:

            query = "insert into `" + table_name + "` " \
                                                   "(ltp, order_type, place_at) " \
                                                   "values (%s, %s, %s);"
            result = cursor.execute(query,
                                    (order_data[0],
                                     order_data[1],
                                     order_data[2]
                                     ))
            result = cursor.lastrowid
            log_debug("{} :{}".format(query, result))
            connection.commit()
    finally:
        connection.close()

    return result

def update_order_data(order_id, order):
    connection = get_connection()
    result = None
    try:
        with connection.cursor() as cursor:
            query = "update `orders` set order_status=%s, last_sent=%s where id=%s;"
            result = cursor.execute(query, (order['status'], order['last_sent'], order_id))
            log_debug("{} :{}".format(query, result))

        connection.commit()
    finally:
        connection.close()
    return result

def get_config_data(timeframe, symbol):
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from psar_config where timeframe=%s and symbol=%s;"
            cursor.execute(query, (timeframe,symbol))
            result = cursor.fetchone()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return ConfigData(*result)

def update_config_data(counter, a, b, trend, ep, psar, old_trend, old_psar, k1, config_id):
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "update `psar_config` set counter = %s, a=%s, b=%s, trend=%s, ep=%s, psar=%s, old_trend=%s,  old_psar=%s, k1=%s where id=%s;"
            result = cursor.execute(query, (counter ,a, b, trend, ep, psar, old_trend, old_psar, k1, config_id))
            log_debug("{} :{}".format(query, result))
        connection.commit()
    finally:
        connection.close()
    return result

def get_trade_data(exchange, symbol, limit=7):
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` order by `id` desc limit %s;"
            cursor.execute(query, (limit,))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [TradeData(*row) for row in result]

def get_trade_data_from(exchange, symbol, start_time, end_time):
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` where created_at between %s and %s order by `id` desc;"
            cursor.execute(query, (start_time, end_time))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [TradeData(*row) for row in result]

def local_get_trade_data(exchange, symbol):
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` order by `id` asc;"
            cursor.execute(query, ())
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [TradeData(*row) for row in result]

def save_trade_profit(exchange, symbol, trade_id, comment, profit, order_type):
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = None
    try:
        with connection.cursor() as cursor:
            query = "update `" + table_name + "` set comment=%s, profit=%s, order_type=%s where id=%s;"
            result = cursor.execute(query, (comment, profit, order_type, trade_id))
            log_debug("{} :{}".format(query, result))

        connection.commit()
    finally:
        connection.close()
    return True if result else False

def save_trade_comment(exchange, symbol, trade_id, comment):
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = None
    try:
        with connection.cursor() as cursor:
            query = "update `" + table_name + "` set comment=%s where id=%s;"
            result = cursor.execute(query, (comment, trade_id))
            log_debug("{} :{}".format(query, result))

        connection.commit()
    finally:
        connection.close()
    return True if result else False

def save_trade_data(exchange, symbol, trade_data):
    # type: (str, str, PsarData) -> int
    table_name = MYSQL_CONFIG.PSAR_TRADE_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:

            query = "insert into `" + table_name + "` " \
                                                   "(ltp, psar, trend_5, psar_5, trend_15, psar_15, trend_30, psar_30) " \
                                                   "values (%s, %s, %s, %s, %s, %s, %s, %s);"
            result = cursor.execute(query,
                                    (trade_data.ltp,
                                     trade_data.psar,
                                     trade_data.trend_5,
                                     trade_data.psar_5,
                                     trade_data.trend_15,
                                     trade_data.psar_15,
                                     trade_data.trend_30,
                                     trade_data.psar_30
                                     ))

            log_debug("{} :{}".format(query, result))
            connection.commit()
    finally:
        connection.close()

    return result

def save_psar_data(exchange, symbol, timeframe, psar_data):
    # type: (str, str, PsarData) -> int
    table_name = MYSQL_CONFIG.PSAR_DATA_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol, timeframe=timeframe)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:

            query = "insert into `" + table_name + "` " \
                                                   "(open, high, low, close, dt, psar, trend, ep, acc, k, current_psar) " \
                                                   "values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
            result = cursor.execute(query,
                                    (psar_data.open,
                                     psar_data.high,
                                     psar_data.low,
                                     psar_data.close,
                                     psar_data.dt,
                                     psar_data.psar,
                                     psar_data.trend,
                                     psar_data.ep,
                                     psar_data.acc,
                                     psar_data.k,
                                     psar_data.current_psar))

            log_debug("{} :{}".format(query, result))
            connection.commit()
    finally:
        connection.close()

    return result


def save_ltp_data(exchange, symbol, ltp_data):
    # type: (str, LtpData) -> int
    table_name = MYSQL_CONFIG.LTP_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "insert into `" + table_name + "` (ltp) values (%s);"
            result = cursor.execute(query, (ltp_data.ltp,))
            log_debug("{} :{}".format(query, result))
            connection.commit()
    finally:
        connection.close()

    return result


def save_keys_data(data):
    connection = get_connection()
    table_name = MYSQL_CONFIG.TRADE_CONFIG_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    result = []
    try:
        start = time.time()
        with connection.cursor() as cursor:
            for config in data:
                val = data[config]
                query = "SELECT count(*) FROM `" + table_name + "` where config=%s"
                cursor.execute(query, (config,))
                result = cursor.fetchone()
                if result[0]:
                    query = "update `"+ table_name + "` set val=%s where config=%s"
                    cursor.execute(query, (val, config))
                    connection.commit()
                else:
                    query = "insert into `"+ table_name + "` (config, val, status) VALUES(%s, %s, %s)"
                    cursor.execute(query, (config, val, 1))
                    connection.commit()
	    
        log_debug2('time keys:{}'.format(time.time() - start))
    finally:
        connection.close()

    return result

def get_keys_data(exchange, symbol, key = None):
    connection = get_connection()
    table_name = MYSQL_CONFIG.TRADE_CONFIG_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    result = []
    log_debug2('fetching keys...')
    try:
        with connection.cursor() as cursor:
            if key != None:
                query = "SELECT * FROM `" + table_name + "` where config=%s"
                cursor.execute(query, (key,))
            else:
                query = "SELECT * FROM `" + table_name + "` where status=1"
                cursor.execute(query)

            result = cursor.fetchall()
    finally:
        connection.close()

    return result


def save_bsq_data(exchange, symbol, bsq_data):
    # type: (str, BSQData) -> int
    table_name = MYSQL_CONFIG.BSQ_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "insert into `" + table_name + "` " \
                                                   "(ltp, buy_qty, sell_qty, diff, trend, order_placed) " \
                                                   "values (%s, %s, %s, %s, %s, %s);"
            result = cursor.execute(query,
                                    (bsq_data.ltp,
                                     bsq_data.buy_qty,
                                     bsq_data.sell_qty,
                                     bsq_data.diff,
                                     bsq_data.trend,
                                     bsq_data.order_placed))
            log_debug("{} :{}".format(query, result))
            connection.commit()
    finally:
        connection.close()

    return result


def get_bsq_order_placed_flag(exchange, symbol):
    table_name = MYSQL_CONFIG.BSQ_TABLE_NAME_TEMPLATE.format(exchange=exchange, symbol=symbol)
    connection = get_connection()
    result_flag = False
    try:
        with connection.cursor() as cursor:
            query = "select * from `" + table_name + "` where order_placed=%s and created_at > %s;"
            cursor.execute(query, (1, utils.today()))
            result = cursor.fetchall()
            result_flag = result is not None and len(result) > 0
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return result_flag


def get_bsq_settings(enabled=1):
    # type: (int) -> list[BSQSetting]
    """
    get buy_sell_qty_settings settings
    """
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select * from `buy_sell_qty_settings` where enabled=%s;"
            cursor.execute(query, (enabled,))
            result = cursor.fetchall()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()
    return [BSQSetting(*row) for row in result]


def save_token_from_kite_token():
    connection = get_connection()
    result = []
    try:
        with connection.cursor() as cursor:
            query = "select access_tokens, date from `kite_token` order by date desc limit 1;"
            cursor.execute(query)
            result = cursor.fetchone()
            log_debug("{} :{}".format(query, result))
    finally:
        connection.close()

    save_access_token("WK2812", result[0])


if __name__ == '__main__':
    ensure_db()
    # ensure_data_table("SBIN", "5m")
    # ensure_data_table("SBIN", "30m")
    # ensure_data_table("NIFTYIT19NOVFUT", "30m")
    # ensure_data_table("CRUDEOIL20JANFUT", "30m")
    # ensure_data_table("RELIANCE", "30m")
    # save_psar_setting(PsarSetting("CRUDE_1MIN", "MCX", "CRUDEOIL20JANFUT", "5m", 0.03, 0.07, 0.03, 0.25))
    # save_psar_setting(PsarSetting("CRUDE_1MIN", "MCX", "CRUDEOIL20JANFUT", "10m", 0.03, 0.07, 0.03, 0.25))
    # save_psar_setting(PsarSetting("CRUDE_1MIN", "MCX", "CRUDEOIL20JANFUT", "15m", 0.03, 0.07, 0.03, 0.25))
    # save_psar_setting(PsarSetting("CRUDE_1MIN", "MCX", "CRUDEOIL20JANFUT", "30m", 0.03, 0.07, 0.03, 0.25))
    for p in get_psar_settings():
        print(p)
