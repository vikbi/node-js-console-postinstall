import heapq
import shutil
import tempfile
import time
from datetime import datetime, timedelta, date
from math import isnan, isinf

from kiteconnect import KiteConnect

isinf
inf = float("inf")
import pandas as pd

from src._logger import *
from src import DATE_FORMAT, TODAY, DATETIME_FORMAT

__author__ = "pryrnjn"


def parse_entry_time_from_file(file_path):
    """parse entry time from settings-file"""
    try:
        settings = get_settings_df(file_path)
        entry_time = settings.EntryTime
        time_tuple = time.strptime(entry_time, '%H:%M:%S')
        return time_tuple.tm_hour, time_tuple.tm_min, time_tuple.tm_sec
    except:
        return None


def parse_entry_time(settings_df):
    """parse entry time from settings-dataframe"""
    return parse_time(settings_df, 'EntryTime')


def parse_exit_time(settings_df):
    """parse entry time from settings-dataframe"""
    return parse_time(settings_df, 'ExitTime')


def parse_time(settings_df, field, time_format='%H:%M:%S'):
    """
    Parses time fields from csv's pandas Dataframe object
    :param settings_df: pd.Dataframe object of the csv file
    :param field: fieldName
    :param time_format:
    :return: tuple (h, m, s) or None
    """
    try:
        _time = settings_df[field]
        time_tuple = time.strptime(_time, time_format)
        return time_tuple.tm_hour, time_tuple.tm_min, time_tuple.tm_sec
    except:
        return None


def get_settings_df(settings_path, index_col=0):
    """
    This throws exception if the file is not found or have other than 1 entry for today,
    so, it can be used for validation as well
    """
    csv_path, json_path = None, None
    if settings_path.find(".csv") > 0:
        csv_path = settings_path
        json_path = settings_path.replace(".csv", ".json")
    elif settings_path.find(".json") > 0:
        json_path = settings_path
        csv_path = settings_path.replace(".json", ".csv")

    settings = read_json(json_path, raise_error=False)  # preference to json settings
    if len(settings) == 0:  # to support legacy csv settings
        settings = pd.read_csv(csv_path, index_col=index_col)
        settings = filter_df_by_date(settings, TODAY)
        if len(settings) == 0:
            raise ValueError('Settings file doesn\'t have today\'s entry.')
        elif len(settings) > 1:
            raise ValueError('Settings file have more than 1 entry for today.')
        elif len(settings) < 1:
            raise ValueError('Something weird happened while reading settings file, recheck file.')
        else:
            return settings.iloc[0]

    return settings


# noinspection PyBroadException
def get_settings_df_by_strategy(strategy, date_column=0):
    # type: (str) -> pd.DataFrame
    try:  # try if file exists in its own path
        return get_settings_df(get_path('%s/files/settings.csv' % strategy), index_col=date_column)
    except:  # if sub-strategy, try for file in the parent strategy folder, use name as per convention
        temp_arr = strategy.split('_')
        if len(temp_arr) > 1:  # check if its a sub-strategy
            parent_str, sub_str = temp_arr[0:2]
            parent_df = get_settings_df(get_path('{}/files/settings.csv'.format(parent_str)), index_col=date_column)
            sub_df = get_settings_df(get_path('{}/files/{}_settings.csv'.format(parent_str, sub_str)),
                                     index_col=date_column)
            return sub_df  # TODO return superimposition of sub_df on parent_df (to achieve inheritance)
        else:
            raise


def filter_df_by_date(df, fdate=TODAY):
    df.rename(index={'today': TODAY}, inplace=True)
    return df.loc[df.index == fdate]


def get_dt_from_hms(dt, hms_tuple):
    h, m, s = hms_tuple
    if isinstance(dt, datetime):
        return dt.replace(hour=h, minute=m, second=s, microsecond=0)


def parse_float(val, default=None, precision=2):
    # type: (object, float, int) -> float
    """

    :rtype: float
    """
    try:
        val = float(val)
        if isnan(val):
            raise ValueError('NaN value.')
        return round(val, precision)
    except:
        if default is not None:
            return default
        raise


def parse_int(val, default=None):
    try:
        return int(val)
    except:
        if default is not None:
            return default
        raise


def parse_str(val, default=None):
    try:
        return str(val).strip()
    except:
        if default is not None:
            return default
        raise


def nlargest(top, l, key=None):
    """if top = 0 or None, returns the full list sorted-in-place"""
    top = top or len(l)
    return heapq.nlargest(top, l, key=key)


def is_200(resp):
    return resp.status_code == 200


def str_error_cause(resp):
    return '{}: {} for url {}'.format(resp.status_code, resp.reason, resp.url)


def get_start_of_year(dt=TODAY, dt_format=DATE_FORMAT):
    dt = dt if type(dt) is datetime else datetime.strptime(dt, dt_format)
    return datetime(dt.year, 1, 1)


def get_start_of_next_year(dt=TODAY, dt_format=DATE_FORMAT):
    dt = dt if type(dt) is datetime else datetime.strptime(dt, dt_format)
    return datetime(dt.year + 1, 1, 1)


def get_end_of_year(dt=TODAY, dt_format=DATE_FORMAT):
    dt = dt if type(dt) is datetime else datetime.strptime(dt, dt_format)
    return datetime(dt.year, 12, 31)


def get_start_of_month(dt=TODAY, dt_format=DATE_FORMAT):
    dt = dt if type(dt) is datetime else datetime.strptime(dt, dt_format)
    return datetime(dt.year, dt.month, 1)


def get_end_of_month(dt=TODAY, dt_format=DATE_FORMAT):
    dt = dt if type(dt) is datetime else datetime.strptime(dt, dt_format)
    return datetime(dt.year, dt.month, 30 if dt.month in [4, 6, 9, 11] else 31
    if dt.month in [1, 3, 5, 7, 8, 10, 12] else 29 if dt.year % 4 == 0 else 28)


def get_printable_object(obj):
    obj_str = ''
    for key, val in obj.__dict__.iteritems():
        obj_str += '{}\t{}\n'.format(key, val)
    return obj_str


def equals(str1, str2, ignorecase=True):
    try:
        if ignorecase:
            return str1.lower() == str2.lower()
        else:
            return str1 == str2
    except:
        return False


def get_instrument_format(stock, exchange=KiteConnect.EXCHANGE_NSE):
    return '%s:%s' % (exchange, stock)


def stringify_df_row(row):
    return ", ".join([str(k) + ' ' + str(v) for k, v in row.iteritems()])


def write_report(df_rows, columns, now, tag, recipient=None):
    df = pd.DataFrame(sorted(df_rows, key=lambda x: x.stock),
                      columns=columns)
    # df.to_csv(get_path('{}/files/analysis{}.csv'.format(TAG, now)))

    with tempfile.NamedTemporaryFile(mode='r+') as temp:
        df.to_csv(temp.name, index=False)
        send_doc_to_telegram(temp, '{}_analysis_{}.csv'.format(tag, now), recipient=recipient)


def get_placed_order_details_msg(tag, orders):
    message = 'Strategy {}:\n'.format(tag)
    if orders:
        message += '\n'.join(
            ['{}'.format(order) for order in filter(lambda _order: _order.order_id is not None, orders)])
        failed_msg = '\n'.join((
            ['{}, Reason: {}'.format(order, order.failure_reason) for order in
             filter(lambda _order: _order.order_id is None, orders)]))
        message += '\n\nFailed Orders:\n' + failed_msg if failed_msg else ''
    else:
        message += 'No orders placed.'

    return message


def get_exit_order_details_msg(tag, orders, symbol_key='symbol'):
    message = 'Strategy {}:\nExited Orders:\n'.format(tag)
    if orders:
        message += ', '.join(
            ['{}'.format(order[symbol_key]) for order in
             filter(lambda order: order.get('failure_reason', None) is None, orders)])
        failed_msg = ', '.join((
            ['{}'.format(order[symbol_key]) for order in
             filter(lambda order: order.get('failure_reason', None) is not None, orders)]))
        # TODO: check for child orders exit status, maybe, also
        message += '\n\nFailed Exiting Orders:\n' + failed_msg if failed_msg else ''
    else:
        message += 'No orders to exit.'
    return message


def get_placed_order_details_msg_from_kite_orders(tag, orders):
    message = 'Strategy {}:\nPlaced Orders:\n'.format(tag)
    if orders:
        message += ', '.join(
            ['{}'.format(order['tradingsymbol']) for order in
             filter(lambda order: order.get('failure_reason', None) is None, orders)])
        failed_msg = ', '.join((
            ['{}'.format(order['tradingsymbol']) for order in
             filter(lambda order: order.get('failure_reason', None) is not None, orders)]))
        message += '\n\nFailed Orders:\n' + failed_msg if failed_msg else ''
    else:
        message += 'No orders to exit.'
    return message


def get_order_updates_detail_msg(tag, orders, order_type="trigger", prefix=''):
    message = 'Strategy {}{}:\n'.format(tag, " - " + prefix if prefix else prefix)
    if orders:
        message += '\n'.join(
            ['{} {} at {}'.format(order.get('tradingsymbol', order.get('symbol', None)), order['transaction_type'],
                                  order['trigger_price'] if order_type == "trigger" else order['price']) for order
             in
             filter(lambda order: order.get('failure_reason', None) is None, orders)])
        failed_msg = ', '.join((
            ['{}: {}'.format(order.get('tradingsymbol', order.get('symbol', None)), order['failure_reason']) for order
             in
             filter(lambda order: order.get('failure_reason', None) is not None, orders)]))
        message += '\n\nFailed Updates:\n' + failed_msg if failed_msg else ''
    else:
        message += 'No Updates.'
    return '' if 'No Updates.' in message else message


def log_exit_order_details_message(tag, orders, prefix='', sortby='symbol', symbol_key='symbol'):
    orders = sorted(orders, key=lambda x: x[sortby])
    msg = get_exit_order_details_msg(tag, orders, symbol_key)
    if type(prefix) is str and prefix.strip() != '':
        msg = '{} {}'.format(prefix, msg)
    log_to_telegram(msg)


def log_rev_order_details_message(tag, orders):
    orders = sorted(orders, key=lambda x: x['tradingsymbol'])
    log_to_telegram(get_placed_order_details_msg_from_kite_orders(tag, orders))


def log_order_details_message(tag, orders, prefix=''):
    orders = sorted(orders, key=lambda x: x.symbol)
    msg = get_placed_order_details_msg(tag, orders)
    if type(prefix) is str and prefix.strip() != '':
        msg = '{} {}'.format(prefix, msg)
    log_to_telegram(msg)


def log_trailing_sl_updates_message(tag, orders):
    log_to_telegram(get_order_updates_detail_msg(tag, orders))


def is_holiday(dt=None, exchange=None):
    holidays = set(['2018-10-18',
                    '2018-11-07',
                    '2018-11-08',
                    '2018-11-23',
                    '2018-12-25',
                    '2019-03-04',
                    '2019-03-21',
                    '2019-04-17',
                    '2019-04-19',
                    '2019-05-01',
                    '2019-06-05',
                    '2019-08-12',
                    '2019-08-15',
                    '2019-09-02',
                    '2019-09-10',
                    '2019-10-02',
                    '2019-10-08',
                    '2019-10-28',
                    '2019-11-12',
                    '2019-12-25'
                    ])
    dt = dt or datetime.strptime(TODAY, DATE_FORMAT)
    return dt.isoweekday() > 5 or dt.strftime(DATE_FORMAT) in holidays


def day_before(date_str=None, by=1, dt_format=None, return_datetime_obj=False):
    """
    Returns (trade) day before by num of days (param by). It only counts a trade day as a day
    :return:
    """
    dt_format = dt_format or DATE_FORMAT
    dt = datetime.strptime(date_str or today(dt_format), dt_format) if type(date_str) is not datetime else date_str

    while by > 0:
        dt -= timedelta(days=1)
        by -= 1
        while is_holiday(dt):
            dt -= timedelta(days=1)

    return dt if return_datetime_obj else dt.strftime(dt_format)


def today(dt_format=None):
    return time.strftime(dt_format or DATE_FORMAT)


def timenow(time_format=None):
    return time.strftime(time_format or DATETIME_FORMAT)


def date_diff(to_date, date_format=DATE_FORMAT, from_date=None):
    from_date = from_date or today(date_format)
    return (datetime.strptime(to_date, date_format) - datetime.strptime(from_date, date_format)).days


def calc_in_perc(price, base_price):
    return abs(parse_float(100.0 * (1.0 * price / base_price - 1)))  # in percent


def date_str_by_day_distance(day_distance=0, date_format=DATE_FORMAT):
    return (datetime.now() - timedelta(days=day_distance)).strftime(date_format)


def touch_file(f, makedir=False):
    if makedir:
        makedirs(f)
    with open(f, "a+"):
        pass


def copytree(src, dst, symlinks=False, ignore=True):
    shutil.copytree(src, dst, symlinks=symlinks, ignore=ignore)


def copyfile(src, dst, create=True, mkdirs=True):
    if mkdirs:
        makedirs(dst)
    if create:
        open(dst, 'a').close()
    shutil.copyfile(src, dst)


def makedirs(path):
    dir_path = os.path.dirname(path)
    os.path.exists(dir_path)
    try:
        os.makedirs(dir_path)
    except OSError as e:
        if e.errno == errno.EEXIST:  # already exists
            pass  # good to know!
        else:
            raise
    return dir_path


import json


class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            encoded_object = obj.strftime(DATETIME_FORMAT)
        elif isinstance(obj, date):
            encoded_object = obj.strftime(DATE_FORMAT)
        else:
            encoded_object = json.JSONEncoder.default(self, obj)
        return encoded_object


def write_to_json_file(data, file_path, encoder_class=DateTimeEncoder):
    with open(file_path, 'w') as outfile:
        json.dump(data, outfile, cls=encoder_class)


def write_to_file(data, file_path):
    with open(file_path, 'w') as outfile:
        outfile.write(data)


def read_file(file_path, raise_error=True):
    data = ""
    try:
        with open(file_path, 'r') as f:
            data = f.read()
    except:
        if raise_error:
            raise
    return data


def read_json(file_path, raise_error=True):
    data = {}
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
    except:
        if raise_error:
            raise
    return data


def calculate_in_multiple_of_ticks(price, tick=0.05):
    return int(round(price / tick)) * tick


if __name__ == '__main__':
    # df = get_settings_df_by_strategy('ohl_m82mtsl')
    # print df
    print (today())
    print (is_holiday())
    print(day_before(by=1))
    a = get_settings_df(get_path('{}/files/settings.csv'.format("StrategyTemplate")))
    print(a)
    a = get_settings_df(get_path('{}/files/settings.csv'.format("AdvancedOrders")))
    print(a)
    # print read_json(get_path('{}/files/settings.json'.format("StrategyTemplate")))
    # print read_json(get_path('{}/files/settings.json'.format("AdvancedOrders")))
    pass
