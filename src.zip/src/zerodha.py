import os
import sys
from datetime import datetime
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from _logger import *
from src import clients, utils

__author__ = "pryrnjn"
kite = None
kws = None


def set_kite_kws():
    global kite, kws
    kite = clients.get_default_client_kite()
    kws = clients.get_default_client_kws()


# def handle_zerodha_token_error():
#     log_error(
#         'Session has expired. Login url {}'.format(kite.login_url()))
#
#
# kite.set_session_expiry_hook(handle_zerodha_token_error)

# test the token
if __name__ == '__main__':
    try:
        kite = clients.get_default_client_kite()
        p = kite.profile()
        print 'Your details', p
        log_to_telegram('{}: You are logged in. Details {}'.format('Session Validation', p))
        if utils.is_holiday(datetime.now()):
            log_to_telegram('It\'s a holiday!')
    except:
        log_exception_to_telegram('{}: Seems no default account is logged out.'.format('Session Validation'))
