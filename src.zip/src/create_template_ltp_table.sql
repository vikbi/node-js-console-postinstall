create TABLE IF NOT EXISTS `ltp_{exchange}_{symbol}` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ltp` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
