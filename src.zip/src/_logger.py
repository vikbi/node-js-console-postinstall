import errno
import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler
from shutil import copyfile

import telegram
# from telegram.error import NetworkError

from src import get_path, join_path, config

# FORMAT = '%(asctime)-15s - %(levelname)s - %(module)s: %(message)s'
# log_file_path = get_path("../logs/alt_%s.log" % TODAY)
# print log_file_path
# logging.basicConfig(format=FORMAT, level=logging.DEBUG)
# _logger = logging.getLogger(__name__)

logname = join_path(config.LOG_HOME_PATH, "algotrades.log")
handler = TimedRotatingFileHandler(logname, when="midnight", interval=1)
handler.suffix = "%Y%m%d"
handler.setFormatter(logging.Formatter('%(asctime)-15s - %(levelname)s - %(module)s: %(message)s'))
_logger = logging.getLogger(__name__)
_logger.addHandler(handler)
_logger.setLevel(logging.DEBUG)

__existing_loggers = set()


def set_logger(name):
    pass


bot = telegram.Bot(token=config.TELEGRAM_BOT_TOKEN)
CHAT_ID = config.TELEGRAM_CHANNEL_CHAT_ID
TELEGRAM_PREFIX = None


# just logs to log file with level DEBUG
def log_debug(msg, *args, **kwargs):
    # msg = "%s: %s" % (TAG, msg)
    _logger.debug(msg, *args, **kwargs)
    # log_to_telegram(msg)


# important logs, goes to log file with level INFO along with telegram channel
def log_info(msg, *args, **kwargs):
    _logger.info(msg, *args, **kwargs)


# exceptions logs, goes to log file as well as telegram channel
def log_exception(msg, *args, **kwargs):
    _logger.exception(msg, *args, **kwargs)


# exceptions logs, that are not necessarily cause a system failure
def log_warning(msg, *args, **kwargs):
    _logger.warn(msg, *args, **kwargs)


# exceptions logs, goes to log file as well as telegram channel
def log_error(msg, *args, **kwargs):
    msg = "ACTION ALERT! : %s" % msg
    _logger.error(msg, *args, **kwargs)
    log_to_telegram(msg)


def log_to_telegram(msg, prefix=None, recipient=None):
    try:
        prefix = prefix or TELEGRAM_PREFIX
        msg = '{}: {}'.format(prefix, msg) if prefix else str(msg)
        if msg and config.TELEGRAM_LOGS_ENABLED:
            bot.send_message(chat_id=CHAT_ID if not recipient else recipient, text=msg[:4096])
    # except NetworkError as e:
    #     log_warning('{} Unable to reach telegram'.format(e.message))
    #     log_debug(msg)
    except:
        log_warning('Couln\'t log_to_telegram.')
        log_debug(msg)


def log_to_telegram_signals_channel(msg, prefix=None):
    log_to_telegram(msg, prefix, config.TELEGRAM_CHANNEL_TRADE_SIGNALS_CHAT_ID)


def send_doc_to_telegram(doc, file_name=None, caption=None, recipient=None):
    try:
        bot.send_document(chat_id=CHAT_ID if not recipient else recipient, document=doc, filename=file_name,
                          caption=caption)
    except:
        import tempfile

        if isinstance(doc, tempfile._TemporaryFileWrapper):
            file_path = get_path('../telegram/unsent_files/{}'.format(file_name or doc.name))

            # makedirs
            if not os.path.exists(os.path.dirname(file_path)):
                try:
                    os.makedirs(os.path.dirname(file_path))
                except OSError as exc:  # Guard against race condition
                    if exc.errno != errno.EEXIST:
                        raise

            # copy content at known location
            copyfile(doc.name, file_path)
            log_debug('Failed sending doc to telegram,  wrote at {}'.format(file_path))
        else:
            log_exception('Failed to send doc.')


def log_exception_to_telegram(msg, *args, **kwargs):
    _logger.exception(msg, *args, **kwargs)
    try:
        if sys.exc_info() and len(sys.exc_info()) > 0 and sys.exc_info()[1] and sys.exc_info()[1].message:
            msg = '{}\nReason: {}'.format(msg, sys.exc_info()[1].message)
    except:
        pass
    log_to_telegram(msg)


def set_telegram_chat_id(chat_id):
    global CHAT_ID
    CHAT_ID = chat_id


def set_common_telegram_prefix(prefix):
    global TELEGRAM_PREFIX
    TELEGRAM_PREFIX = prefix


def start_log(_strategy, _type):
    log_to_telegram('Started %s strategy for %s' % (_type, _strategy))


def exit_log(_strategy, _type):
    log_to_telegram('Exited %s strategy for %s' % (_type, _strategy))


if __name__ == "__main__":
    a = bot.get_updates()
    print(a)
