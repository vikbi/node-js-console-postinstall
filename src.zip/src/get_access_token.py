import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from src import clients

__author__ = "pryrnjn"

if __name__ == "__main__":
    client_id = raw_input("""Client Id?
    """)

    request_token = raw_input("""
    Hi!  Login to the app using url %s
    After 2fa authentication, extract request_token from the URL, paste below and ENTER.
    """ % clients.get_login_url(client_id))
    clients.generate_access_token_from_req_token(request_token, client_id)

