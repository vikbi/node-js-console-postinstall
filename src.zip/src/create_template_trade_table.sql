CREATE TABLE IF NOT EXISTS `trade_{exchange}_{symbol}` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `ltp` float NOT NULL,
  `psar` float NOT NULL,
  `trend_5` tinyint(4) NOT NULL,
  `psar_5` float NOT NULL,
  `trend_15` tinyint(4) NOT NULL,
  `psar_15` float NOT NULL,
  `trend_30` tinyint(4) NOT NULL,
  `psar_30` float NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text,
  `profit` float DEFAULT NULL,
  `order_type` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
