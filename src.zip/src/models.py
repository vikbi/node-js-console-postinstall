__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

from decimal import Decimal

from src import auto_str, candles
from src._logger import *


@auto_str
class Symbol:
    def __init__(self, exchange, symbol, enabled, created_at, updated_at):
        self.exchange = exchange
        self.symbol = symbol
        self.enabled = enabled
        self.created_at = created_at
        self.updated_at = updated_at


@auto_str
class PsarSetting(object):
    def __init__(self, title, exchange, symbol, timeframe, min_acc, max_acc, acc, dacc, enabled=1, created_at=None,
                 updated_at=None):
        self.title = title
        self.exchange = exchange
        self.symbol = symbol
        self.timeframe = timeframe
        self.min_acc = min_acc
        self.max_acc = max_acc
        self.acc = acc
        self.dacc = dacc
        self.enabled = enabled
        self.created_at = created_at
        self.updated_at = updated_at


@auto_str
class BSQSetting(object):
    def __init__(self, title, exchange, symbol, timeframe, diff_threshold, order_type, order_qty, sl, target, tsl,
                 enabled=1, created_at=None, updated_at=None):
        self.title = title
        self.exchange = exchange
        self.symbol = symbol
        self.timeframe = int(timeframe.replace("s", ""))
        self.diff_threshold = diff_threshold
        self.order_type = order_type
        self.order_qty = order_qty
        self.sl = sl
        self.target = target
        self.tsl = tsl
        self.enabled = enabled
        self.created_at = created_at
        self.updated_at = updated_at


@auto_str
class LtpData(object):
    def __init__(self, id, ltp, created_at=None):
        self.id = id
        self.ltp = ltp
        self.created_at = created_at

@auto_str
class ConfigData(object):
    def __init__(self, id, symbol, timeframe, a, b, counter, trend, ep, psar, old_psar, old_trend, k1, created_at=None, updated_at=None):
        self.id = id
        self.symbol = symbol
        self.timeframe = timeframe
        self.a = a
        self.b = b
        self.counter = counter
        self.trend = trend
        self.ep = ep
        self.psar = psar
        self.old_psar = old_psar
        self.old_trend = old_trend
        self.k1 = k1
        self.created_at = created_at
        self.updated_at = updated_at

@auto_str
class TradeData(object):
    def __init__(self,id, ltp, psar, trend_5, psar_5, trend_15, psar_15, trend_30, psar_30, created_at=None, comment=None, profit=None, order_type=None):
        self.id = id
        self.ltp = ltp
        self.psar = psar
        self.trend_5 = trend_5
        self.psar_5 = psar_5
        self.trend_15 = trend_15
        self.psar_15 = psar_15
        self.trend_30 = trend_30
        self.psar_30 = psar_30
        self.created_at = created_at
        self.comment = comment
        self.profit = profit
        self.order_type = order_type
@auto_str
class OrderData(object):
    def __init__(self, id, ltp, order_type, order_status, place_at, last_sent, created_at, updated_at, comment=None):
        self.id = id
        self.ltp = ltp
        self.order_type = order_type
        self.order_status = order_status
        self.place_at = place_at
        self.last_sent = last_sent
        self.created_at = created_at
        self.comment = comment
        self.updated_at = updated_at
@auto_str
class BSQData(object):
    def __init__(self, id, ltp, buy_qty, sell_qty, diff, trend, order_placed, created_at=None, updated_at=None):
        self.id = id
        self.ltp = ltp
        self.buy_qty = buy_qty
        self.sell_qty = sell_qty
        self.diff = diff
        self.trend = trend
        self.order_placed = order_placed

    @classmethod
    def build(cls, ltp, buy_qty, sell_qty, threshold, already_placed):
        # type: (float, int, int, float, bool) -> BSQData

        try:
            if buy_qty == sell_qty == 0:
                diff, trend = 0, None
            elif buy_qty <= sell_qty:
                diff, trend = (buy_qty * 100.0) / sell_qty, 0
            else:
                diff, trend = (sell_qty * 100.0) / buy_qty, 1
            order_placed = 1 if diff <= threshold and not already_placed else 0

            bsq_data = cls(None, ltp, buy_qty, sell_qty, diff, trend, order_placed)
        except:
            log_exception("Failed to calculate for {}".format(bsq_data))

        return bsq_data


@auto_str
class PsarData(object):
    def __init__(self, id, open, high, low, close, dt, psar, trend, ep, acc, k, current_psar, created_at=None,
                 updated_at=None):
        self.id = id
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.dt = dt
        self.psar = psar
        self.trend = trend
        self.ep = ep
        self.acc = acc
        self.k = k
        self.current_psar = current_psar

    @classmethod
    def build(cls, candle, prev_psar_datas, psar_setting):
        # type: (candles.Candle, list[PsarData], PsarSetting) -> PsarData
        psar_data = cls(None, Decimal(candle.open), Decimal(candle.high), Decimal(candle.low), Decimal(candle.close),
                        candle.datetime, None, None, None, None, None, None)
        try:
            PsarData.calculate_psar(psar_data, prev_psar_datas)
            PsarData.calculate_trend(psar_data, prev_psar_datas)
            PsarData.calculate_ep(psar_data, prev_psar_datas)
            PsarData.calculate_acc(psar_data, prev_psar_datas, psar_setting)
            PsarData.calculate_k(psar_data, prev_psar_datas)
            PsarData.calculate_current_psar(psar_data, prev_psar_datas)
        except:
            log_exception("Failed to calculate for {}".format(psar_data))

        return psar_data

    @staticmethod
    def calculate_psar(psar_data, prev_psar_datas):
        # type: (PsarData, list[PsarData]) -> None
        if len(prev_psar_datas) < 2:
            psar_data.psar = None
        elif prev_psar_datas[0].psar is None and prev_psar_datas[1].psar is None:
            psar_data.psar = min(psar_data.low, prev_psar_datas[0].low, prev_psar_datas[1].low)
        else:
            # =IF(AND(I22=1,M22>D23),J22,IF(AND(I22=0, M22<C23),J22,M22))
            if prev_psar_datas[0].trend == 1 and prev_psar_datas[0].current_psar > psar_data.low:
                psar_data.psar = prev_psar_datas[0].ep
            elif prev_psar_datas[0].trend == 0 and prev_psar_datas[0].current_psar < psar_data.high:
                psar_data.psar = prev_psar_datas[0].ep
            else:
                psar_data.psar = prev_psar_datas[0].current_psar

    @staticmethod
    def calculate_trend(psar_data, prev_psar_datas):
        # type: (PsarData, list[PsarData]) -> None
        if len(prev_psar_datas) < 2:
            psar_data.trend = None
        else:
            # =IF(H22<C22,1,0)
            if psar_data.psar < psar_data.high:
                psar_data.trend = 1
            else:
                psar_data.trend = 0

    @staticmethod
    def calculate_ep(psar_data, prev_psar_datas):
        # type: (PsarData, list[PsarData]) -> None
        if len(prev_psar_datas) < 2:
            return
        elif prev_psar_datas[0].psar is None and prev_psar_datas[1].psar is None:
            psar_data.ep = psar_data.high
        else:
            # =IF(AND(I23=1, C23 > J22), C23, IF(AND(I23=1, C23 <= J22), J22, IF(AND(I23=0, D23 < J22), D23, J22)))
            if psar_data.trend == 1 and psar_data.high > prev_psar_datas[0].ep:
                psar_data.ep = psar_data.high
            elif psar_data.trend == 1 and psar_data.high <= prev_psar_datas[0].ep:
                psar_data.ep = prev_psar_datas[0].ep
            elif psar_data.trend == 0 and psar_data.low <= prev_psar_datas[0].ep:
                psar_data.ep = psar_data.low
            else:
                psar_data.ep = prev_psar_datas[0].ep

    @staticmethod
    def calculate_acc(psar_data, prev_psar_datas, psar_setting):
        # type: (PsarData, list[PsarData], PsarSetting) -> None
        if len(prev_psar_datas) < 2:
            psar_data.acc = None
        elif prev_psar_datas[0].psar is None and prev_psar_datas[1].psar is None:
            psar_data.acc = psar_setting.min_acc
        else:
            # =IF(I23=I22,IF(K22>$L$17,$L$17,IF(AND(I23=1,J23>J22),K22+$M$17,IF(AND(I23=1,J23<=J22),K22,IF(AND(I23=0,J23<J22),K22+$K$17,IF(AND(I23=0,J23>=J22),K22))))),$K$17)
            if psar_data.trend == prev_psar_datas[0].trend:
                if prev_psar_datas[0].acc > psar_setting.max_acc:
                    psar_data.acc = psar_setting.max_acc
                elif psar_data.trend == 1 and psar_data.ep > prev_psar_datas[0].ep:
                    psar_data.acc = prev_psar_datas[0].acc + psar_setting.dacc
                elif psar_data.trend == 1 and psar_data.ep <= prev_psar_datas[0].ep:
                    psar_data.acc = prev_psar_datas[0].acc
                elif psar_data.trend == 0 and psar_data.ep < prev_psar_datas[0].ep:
                    psar_data.acc = prev_psar_datas[0].acc + psar_setting.dacc
                elif psar_data.trend == 0 and psar_data.ep >= prev_psar_datas[0].ep:  # it is as good as else
                    psar_data.acc = prev_psar_datas[0].acc
            else:
                psar_data.acc = psar_setting.min_acc

    @staticmethod
    def calculate_k(psar_data, prev_psar_datas):
        # type: (PsarData, list[PsarData]) -> None
        if len(prev_psar_datas) < 2:
            psar_data.k = None
        else:
            # =(J22-H22)*K22  # K = (EP-PSAR)*ACC
            psar_data.k = (psar_data.ep - psar_data.psar) * psar_data.acc

    @staticmethod
    def calculate_current_psar(psar_data, prev_psar_datas):
        # type: (PsarData, list[PsarData]) -> None
        if len(prev_psar_datas) < 2:
            psar_data.current_psar = None
        else:
            # =H22+L22  # CURRENT_SAR = PSAR + K
            psar_data.current_psar = psar_data.psar + psar_data.k
