# telegram
# telegram bot creds
TELEGRAM_BOT_TOKEN = '1240868958:AAGruRaHTkJp2AD_qzrHSdoTGqUTWj8IRpw'
__CHAT_ID_PR = -1001343691866

TELEGRAM_CHANNEL_CHAT_ID = __CHAT_ID_PR
TELEGRAM_M2M_CHAT_ID = __CHAT_ID_PR
TELEGRAM_CHANNEL_TRADE_SIGNALS_CHAT_ID = __CHAT_ID_PR

TELEGRAM_USERS = [
    TELEGRAM_CHANNEL_CHAT_ID
]
# TELEGRAM_LOGS_ENABLED = False
TELEGRAM_LOGS_ENABLED = True


class MYSQL_CONFIG:
    HOST = "localhost"
    PORT = 3306
    USER = "root"
    PASSWORD = "Algo@123"
    DATABASE = "algotrade"
    UNIX_SOCKET = None
    CREATE_DB_FILENAME = "create_tables.sql"
    CREATE_TEMPLATE_FOR_DATA_TABLE_FILENAME = "create_template_data_table.sql"
    CREATE_TEMPLATE_FOR_LTP_TABLE_FILENAME = "create_template_ltp_table.sql"
    CREATE_TEMPLATE_FOR_BSQ_DATA_TABLE_FILENAME = "create_template_bsq_data_table.sql"
    CREATE_TEMPLATE_FOR_TRADE_TABLE_FILENAME = "create_template_trade_table.sql"
    CREATE_TEMPLATE_FOR_TRADE_CONFIG_TABLE_FILENAME = "create_template_trade_config_table.sql"
    CREATE_TEMPLATE_FOR_ORDER_TABLE_FILENAME = "create_template_orders.sql"

    PSAR_DATA_TABLE_NAME_TEMPLATE = "data_{exchange}_{symbol}_{timeframe}"
    LTP_TABLE_NAME_TEMPLATE = "ltp_{exchange}_{symbol}"
    BSQ_TABLE_NAME_TEMPLATE = "bsq_{exchange}_{symbol}"
    PSAR_TRADE_TABLE_NAME_TEMPLATE = "trade_{exchange}_{symbol}"
    TRADE_CONFIG_TABLE_NAME_TEMPLATE = "trade_config_{exchange}_{symbol}"
# m2m
M2M_FREQUENCY = 1  # minutes
GENERATE_REPORT = True

# ForceExit Start Time
FORCE_EXIT_START_TIME = (15, 10, 0)
FORCE_EXIT_RETRY_FREQ = 2  # minutes

# livecandles Times
LIVECANDLES_START_TIME = (9, 00, 0)
LIVECANDLES_END_TIME = (23, 56, 00)
LTP_TIMEFRAME = "60s"

# logs
LOG_HOME_PATH = "/"
