BUY, SELL = 'buy', 'sell'
ENTRY, EXIT, SCREENER = 'ENTRY', 'EXIT', 'SCREENER'
SIMULATOR = 'simulator'
BULLISH, BEARISH = "bullish", "bearish"

CONFIG_KEYS2 = ['bb','trade_es','trend_15', 'trend_30', 'prev_trend_15', 'prev_trend_30', 'current_ltp', 'current_psar','current_time' , 'order_ltp', 'eb', 'es', 'high', 'low', 'np3',
        'trade', 'order_time', 'bt', 'tt', 'bp1', 'm1', 'bu', 'sp1', 'm2', 'sds', 'duck1', 'se', 'order_index', 'ttt',
        'bhigh', 'blow', 'shigh', 'slow', 'order_type', 'prev_order_type', 'current_index', 'temp15_data', 'all_profit_arr', 'prev_minute_ltp', 'total_profit','all_profit', 'notify_profit',
        'alert','alert2','alert5','min_loss','max_loss','s1','alert3','alert4','prev_prev_min_ltp','b1','b3', 'alert6', 'm3', 'prev_min_psar', 'duck2'
        ]

CONFIG_KEYS = ['bb','trade_es','trend_15', 'trend_30', 'prev_trend_15', 'prev_trend_30', 'current_ltp', 'current_psar','current_time' , 'order_ltp', 'eb', 'es', 'high', 'low', 'np3',
        'trade', 'order_time', 'bt', 'tt', 'bp1', 'm1', 'bu', 'sp1', 'm2', 'sds', 'duck1', 'se', 'order_index', 'ttt',
        'bhigh', 'blow', 'shigh', 'slow', 'order_type', 'prev_order_type', 'current_index', 'temp15_data', 'all_profit_arr', 'prev_minute_ltp', 'total_profit','all_profit', 'notify_profit',
        'alert','alert2','alert5','min_loss','max_loss','s1','alert3','alert4','prev_prev_min_ltp','b1','b3', 'alert6', 'm3', 'prev_min_psar', 'duck2', 'exchange', 'symbol',
        'alert7','alert8', 'alert9', 'knock1','knock2', 'knock3', 'knock4', 'small', 'big', 'hu', 'jump_price','jump_price2', 'y5','y6','y7','y8' ,'cn1', 'cn2', 'cn3', 'cn4'
        ]

CONFIG_KEYS_NOTINT = ['order_time', 'order_type', 'prev_order_type', 'current_time','peak']

class Segments:
    FUT = 'FUT'
    EQ = 'EQ'
    PE = 'PE'
    CE = 'CE'


class Exchange:
    NSE = 'NSE'
    NFO = 'NFO'
    MCX = 'MCX'
    BSE = 'BSE'
    BFO = 'BFO'
    CDS = 'CDS'


class OrderType:
    MIS = 'MIS'
    BO = 'BO'
    CO = 'CO'
    CNC = 'CNC'
    NRML = 'NRML'


class Datasources:
    KITE = 'KITE'
    UPSTOX = 'UPSTOX'


class Broker:
    KITE = 'KITE'
    UPSTOX = 'UPSTOX'


class QuoteMode:
    LTP = 'LTP'
    FULL = 'FULL'
