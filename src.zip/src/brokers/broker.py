__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

from abc import abstractmethod


class Broker:
    MAX_RETRY = 10
    REQ_LIMIT_PER_SECOND = 2

    def __init__(self, client_id):
        self.__client_id = client_id

    @abstractmethod
    def configure(self, session):
        pass

    def configure_session(self, api_key, access_token):
        session = self.generate_session_by_access_token(api_key, access_token)
        self.configure(session)

    @abstractmethod
    def get_session(self):
        pass

    @property
    def client_id(self):
        return self.__client_id

    @abstractmethod
    def get_login_url(self, api_key, redirect_uri):
        pass

    @abstractmethod
    def get_profile(self):
        pass

    @abstractmethod
    def generate_access_token_from_req_token(self, api_key, secret_key, request_token, redirect_uri):
        """

        :param api_key:
        :param secret_key:
        :param request_token:
        :param redirect_uri: This is mandatory non-None value for Upstox. For others you can provide None for this.
        :return:
        """
        pass

    @abstractmethod
    def generate_session(self, api_key, secret_key, request_token, redirect_uri):
        """

        :param api_key:
        :param secret_key:
        :param request_token:
        :param redirect_uri: This is mandatory non-None value for Upstox. For others you can provide None for this.
        :return:
        """
        pass

    @abstractmethod
    def generate_session_by_access_token(self, api_key, access_token):
        """

        :param api_key:
        :param access_token:
        :return:
        """
        pass

    def is_session_valid(self):
        # type: () -> bool
        try:
            self.get_profile()
            return True
        except:
            return False

    @abstractmethod
    def get_exchange(self, exchange):
        pass

    @abstractmethod
    def place_order(self, order):
        pass


if __name__ == '__main__':
    Broker("sad")
