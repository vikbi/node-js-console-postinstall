__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

STATUS_OPEN, STATUS_REJECTED, STATUS_CANCELLED, STATUS_CANCELLED_AMO, STATUS_TRIGGER_PENDING, STATUS_COMPLETED, STATUS_PENDING = 'OPEN', 'REJECTED', 'CANCELLED', 'CANCELLED AMO', 'TRIGGER PENDING', 'COMPLETE', 'PENDING'


class Constants:
    ORPHANED = 'orphaned'

    class Market:
        COMMODITY = 'commodity'
        EQUITY = 'equity'

    class Segments:
        FUT = 'FUT'
        EQ = 'EQ'
        PE = 'PE'
        CE = 'CE'

    class Exchange:
        NSE = 'NSE'
        NFO = 'NFO'
        MCX = 'MCX'
        BSE = 'BSE'
        BFO = 'BFO'
        CDS = 'CDS'

    class ProductType:
        MIS = 'MIS'
        BO = 'BO'
        CO = 'CO'
        CNC = 'CNC'
        NRML = 'NRML'

    class TransactionType:
        BUY = 'BUY'
        SELL = 'SELL'

    class OrderType:
        MARKET = "MARKET"
        LIMIT = "LIMIT"
        SLM = "SL-M"
        SL = "SL"

    class Validation:
        IOC = 'IOC'
        DAY = 'DAY'

    class SquareoffType:
        STOPLOSS = 'stoploss'
        TARGET = 'target'
