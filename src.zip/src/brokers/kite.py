__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

from kiteconnect import KiteConnect
import kiteconnect.exceptions as KE
from src._logger import *
from src.brokers.broker import Broker
from src.brokers.constants import Constants


class KiteBroker(Broker):
    _session = None  # type: KiteConnect

    def __init__(self, client_id):
        Broker.__init__(self, client_id)
        self._session = None

    def configure(self, broker):
        self._session = broker
        self.get_profile()

    def get_session(self):
        return self._session

    def get_login_url(self, api_key, redirect_uri):
        return KiteConnect(api_key).login_url()

    def get_profile(self):
        profile_data = self._session.profile()
        profile_data['client_id'] = self.client_id
        return profile_data

    def generate_access_token_from_req_token(self, api_key, secret_key, request_token, redirect_uri):
        kite = KiteConnect(api_key)
        user_data = kite.generate_session(request_token, secret_key)
        access_token = str(user_data["access_token"])
        return access_token

    def generate_session(self, api_key, secret_key, request_token, redirect_uri):
        # type: (str, str, str, str) -> KiteConnect
        kite = KiteConnect(api_key)
        access_token = self.generate_access_token_from_req_token(api_key, secret_key, request_token, redirect_uri)
        kite.set_access_token(access_token)
        return kite

    def generate_session_by_access_token(self, api_key, access_token):
        kite = KiteConnect(api_key)
        kite.set_access_token(access_token)
        return kite

    def place_order(self, order):
        try:
            # self._session.holdings()
            # self._session.positions()

            order_id = self._session.place_order(
                KiteConnect.VARIETY_REGULAR,
                order['exchange'],
                order['symbol'],
                order['transaction_type'],
                order['quantity'],
                KiteConnect.PRODUCT_NRML,
                KiteConnect.ORDER_TYPE_MARKET,
                price=order['price'],
                validity=KiteConnect.VALIDITY_DAY,
                # trigger_price=order.trigger_price,
                #squareoff=order['target'],
                #stoploss=order['sl'],
                #trailing_stoploss=order['tsl'],
                #tag=order['tag']
            )
            if order_id is not None:
                print('order id:',order_id)
                # order.set_order_id(order_id)
                # log_debug("Order placed successfully. Details: {}".format(order))
                return True
            else:
                raise ValueError("Something broke, couldn't receive order_id from Zerodha.")

        except KE.TokenException as e:
            # Denotes session is expired.
            log_exception(
                "ORDER FAILED! The Token expired, refresh it immediately and re run! It will not be retried. "
                "Order was : {}".format(order))
            order.set_failure(e)
        except KE.PermissionException as e:
            # Represents permission denied exceptions for certain calls.
            log_exception(
                "ORDER FAILED! There seems to be permission issue with this type of order. It will not be retried. "
                "Order was : {}".format(order))
            order.set_failure(e)
        except KE.InputException as e:
            # Represents user input errors such as missing and invalid parameters.
            log_exception(
                "ORDER FAILED! There are missing and invalid parameters! Please cross check your input or/and your "
                "developer. It will not be retried. Order was : {}".format(order))
            order.set_failure(e)
        except KE.DataException as e:
            # Represents a bad response from the backend Order Management System (OMS).
            log_exception(
                "ORDER FAILED! This might be an intermittent issue on Zerodha side! It will be retried. "
                "Order was : {}".format(order))
            order.set_failure(e)
            # entry_orders_data['pending'].put((1, order))
        except KE.NetworkException as e:
            # Represents a network issue between Kite and the backend Order Management System (OMS).
            # Or, Too many requests
            log_exception(
                "ORDER FAILED! This looks like an intermittent issue on Zerodha side! It will be retried. "
                "Order was : {}".format(order))
            order.set_failure(e)
            # entry_orders_data['pending'].put((1, order))
        except KE.OrderException as e:
            # Represents all order placement and manipulation errors.
            log_exception(
                "ORDER FAILED! This doesn't seem to be a recoverable issue, you can try placing manual! "
                "It will not be retried. Order was : {}".format(order))
            order.set_failure(e)
        except KE.GeneralException as e:
            # An unclassified, general error.
            log_exception(
                "ORDER FAILED! This doesn't seem to be a recoverable issue, you can try placing manual! "
                "It will not be retried. Order was : {}".format(order))
            order.set_failure(e)
        except KE.KiteException as e:
            # This is the base exception class which has a publicly accessible message and code that is received from
            # Kite Connect api.
            log_exception(
                "ORDER FAILED! This doesn't seem to be a recoverable issue, you can try placing manual! "
                "It will not be retried. Order was : {}".format(order))
            order.set_failure(e)
        except Exception as e:
            log_exception("ORDER FAILED! It happened at our side. It will be retried. Order was : {}".format(order))
            # to retry the order needs to pushed in entry_orders['pending'], and monitor_entry_orders needs to be invoked
            order.set_failure(e)
            # entry_orders_data['pending'].put((5, order))
        return False

    def get_exchange(self, exchange):
        return {
            Constants.Exchange.NSE: KiteConnect.EXCHANGE_NSE,
            Constants.Exchange.BSE: KiteConnect.EXCHANGE_BSE,
            Constants.Exchange.NFO: KiteConnect.EXCHANGE_NFO,
            Constants.Exchange.BFO: KiteConnect.EXCHANGE_BFO,
            Constants.Exchange.MCX: KiteConnect.EXCHANGE_MCX,
            Constants.Exchange.CDS: KiteConnect.EXCHANGE_CDS
        }[exchange]
