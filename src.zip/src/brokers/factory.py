__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

from src.brokers.broker import Broker
from src.brokers.kite import KiteBroker

KITE = 'KITE'


def get_broker_by_name(provider, client_id):
    # type: (str) -> Broker
    if provider == KITE:
        return KiteBroker(client_id)
    else:
        raise NotImplementedError("{} is either misspelled or unsupported Broker.".format(provider))
