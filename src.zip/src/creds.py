from src.classes import *
from src import constants
clients = {}
KITE_API_KEY = ''

api_key_map = {
}

user_details = {
    'UR8440': User('UR8440', constants.Broker.KITE, 397918186)
}

app_details = {
    'UR8440': AppInfo('tzt2n4deew7kv99h','k7gj89c8h3329e6ljwyj2mlhyb427mc5', constants.Broker.KITE, '', True)
}
