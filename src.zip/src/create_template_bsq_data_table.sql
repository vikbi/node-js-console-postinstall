-- Id	open	high	low	close	last_trade_time	data feed time	PSAR	TREND	EP	ACC	K = (EP-PSAR)*ACC	CURRENT_SAR = PSAR + K
CREATE TABLE IF NOT EXISTS `bsq_{exchange}_{symbol}` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ltp` decimal(10,2) NOT NULL,
  `buy_qty` int DEFAULT NULL,
  `sell_qty` int DEFAULT NULL,
  `diff` decimal(10,2) DEFAULT NULL,
  `trend` tinyint(1) DEFAULT NULL,
  `order_placed` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1

