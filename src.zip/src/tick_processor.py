from datetime import datetime
from src import candles, mysqlDatastore, config, LIVE_SAR, TRADE
from src import clients
from src.models import PsarData, LtpData, BSQData, BSQSetting
from src._logger import *
from src._logger2 import *

__symbol_by_instrument = dict()
__symbol_timeframe_subscription = dict()
__symbol_bsq_settings = dict()
__livecandles = dict()
__ltps = dict()
__bsqs = dict()
__bsq_order_placed = dict()
__last_tick_vol = {}
__broker = clients.get_broker("UR8440")

def update_symbol_by_instrument(inst_token, symbol):
    __symbol_by_instrument[inst_token] = symbol


def update_timeframe_subscription(symbol, timeframe):
    if symbol not in __symbol_timeframe_subscription:
        __symbol_timeframe_subscription[symbol] = set()

    mysqlDatastore.ensure_data_table(symbol.split(":")[0], symbol.split(":")[-1], timeframe)
    mysqlDatastore.ensure_ltp_table(symbol.split(":")[0], symbol.split(":")[-1])
    mysqlDatastore.ensure_trade_table(symbol.split(":")[0], symbol.split(":")[-1])
    mysqlDatastore.ensure_trade_config_table(symbol.split(":")[0], symbol.split(":")[-1])
    trade = TRADE.get_instance()
    trade.verify_keys(symbol.split(":")[0], symbol.split(":")[-1])
    __symbol_timeframe_subscription[symbol].add(timeframe)


def update_bsq_subscription(symbol, bsq_setting):
    __symbol_bsq_settings[symbol] = bsq_setting
    mysqlDatastore.ensure_bsq_data_table(symbol.split(":")[0], symbol.split(":")[-1])


def process_tick(tick, is_last_tick={}):
    timestamp = datetime.now()
    ltp, volume = tick['last_price'], tick.get('volume', 0)
    inst_token = tick['instrument_token']
    symbol = __symbol_by_instrument.get(inst_token)
    exchange = symbol.split(':')[0]
    symbol_without_exchange = symbol.split(':')[-1]
    this_is_last_tick = is_last_tick.get(exchange, is_last_tick.get('default', False))

    for timeframe in __symbol_timeframe_subscription.get(symbol, set()):
        resolution_min_step = candles.get_step_minutes(timeframe)
        candle_timestamp = timestamp.replace(minute=(timestamp.minute / resolution_min_step) * resolution_min_step,
                                             second=0,
                                             microsecond=0)
        inst_key = "{}:{}".format(inst_token, timeframe)

        if ltp:
            if inst_key not in __livecandles:
                __livecandles[inst_key] = list()

            if inst_key not in __last_tick_vol:
                __last_tick_vol[inst_key] = -1
            if __last_tick_vol[inst_key] >= 0:
                volume -= __last_tick_vol[inst_key]
                __last_tick_vol[inst_key] += volume
            else:
                __last_tick_vol[inst_key] = volume
                volume = 0
            if not this_is_last_tick and len(__livecandles[inst_key]) > 0 \
                    and __livecandles[inst_key][-1].datetime == candle_timestamp:
                __livecandles[inst_key][-1].update_hlcv(ltp, ltp, ltp, volume)
            else:
                if len(__livecandles[inst_key]) > 0:
                    calculate_and_save_psar_data(exchange, symbol_without_exchange, timeframe, __livecandles[inst_key].pop())
                    log_debug2('in for loop--- {}'.format(timeframe))
                    __livecandles[inst_key].append(candles.Candle(ltp, ltp, ltp, ltp, volume, timeframe, candle_timestamp))

    # storing ltp
    resolution_sec_step = 0
    try:
        resolution_sec_step = int(config.LTP_TIMEFRAME.replace("s", ""))
    except:
        pass

    if resolution_sec_step and symbol in __symbol_timeframe_subscription:
        ltp_timestamp = timestamp.replace(second=(timestamp.second / resolution_sec_step) * resolution_sec_step,
                                          microsecond=0)
        if inst_token not in __ltps:
            __ltps[inst_token] = ltp_timestamp

        if ltp_timestamp != __ltps[inst_token]:
            save_ltp_data(exchange, symbol_without_exchange, ltp)
            save_trade_data(exchange, symbol_without_exchange)
            __ltps.pop(inst_token, None)

    # bsq
    if symbol in __symbol_bsq_settings:
        bsq_setting = __symbol_bsq_settings.get(symbol)
        resolution_sec_step = bsq_setting.timeframe
        ltp_timestamp = timestamp.replace(second=(timestamp.second / resolution_sec_step) * resolution_sec_step,
                                          microsecond=0)
        if inst_token not in __bsqs:
            __bsqs[inst_token] = ltp_timestamp

        if ltp_timestamp != __bsqs[inst_token]:
            calculate_and_save_bsq_data(exchange, symbol_without_exchange, tick, bsq_setting)
            __bsqs.pop(inst_token, None)


def calculate_and_save_psar_data(exchange, symbol, timeframe, candle):
    psar_setting = get_psar_setting(exchange, symbol, timeframe)
    if psar_setting:
        prev_psar_datas = mysqlDatastore.get_psar_data(exchange, symbol, timeframe)
        psar_data = PsarData.build(candle, prev_psar_datas, psar_setting)
        mysqlDatastore.save_psar_data(exchange, symbol, timeframe, psar_data)

def save_ltp_data(exchange, symbol, ltp):
    log_debug2('call save ltp')
    mysqlDatastore.save_ltp_data(exchange, symbol, LtpData(None, ltp))

def save_trade_data(exchange, symbol):
    log_debug2('call save trade data : from caller')
    try:
        LIVE_SAR.main(exchange, symbol)
        log_debug2('sar update sucess : from caller')
        TRADE.main(exchange, symbol)
    except:
        log_debug2('exception call : issue in trade call')
            
def calculate_and_save_bsq_data(exchange, symbol, tick, bsq_setting):
    bsq_data = BSQData.build(
        tick['last_price'],
        tick['buy_quantity'],
        tick['sell_quantity'],
        bsq_setting.diff_threshold,
        get_bsq_order_placed_flag(exchange, symbol))
    if bsq_data.order_placed:
        process_order(bsq_data, bsq_setting)
        __bsq_order_placed["{}:{}".format(exchange, symbol)] = bsq_data.order_placed
    mysqlDatastore.save_bsq_data(exchange, symbol, bsq_data)


def get_bsq_order_placed_flag(exchange, symbol):
    key = "{}:{}".format(exchange, symbol)
    if key not in __bsq_order_placed:
        __bsq_order_placed[key] = mysqlDatastore.get_bsq_order_placed_flag(exchange, symbol)
    return __bsq_order_placed[key]


def process_order(bsq_data, bsq_setting):  # type: (BSQData, BSQSetting) -> list[BSQSetting]
    order = dict()
    order['exchange'] = bsq_setting.exchange
    order['symbol'] = bsq_setting.symbol
    order['transaction_type'] = "SELL" if bsq_data.trend else "BUY"
    order['quantity'] = bsq_setting.order_qty
    order['price'] = bsq_data.ltp
    order['target'] = bsq_setting.target
    order['sl'] = bsq_setting.sl
    order['tsl'] = bsq_setting.tsl or None
    order['tag'] = "bsq"

    status = __broker.place_order(order)
    log_to_telegram("Placing order: {} - {}".format(order, status))


__psar_settings = dict()


def get_psar_setting(exchange, symbol, timeframe):
    key = "{}:{}:{}".format(exchange, symbol, timeframe)
    if key not in __psar_settings:
        psar_settings = mysqlDatastore.get_psar_settings(1)
        for psar_setting in psar_settings:
            __psar_settings["{}:{}:{}".format(psar_setting.exchange, psar_setting.symbol, psar_setting.timeframe)] = psar_setting

    return __psar_settings.get(key, None)

