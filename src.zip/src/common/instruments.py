import json
import os
import sys

__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"
sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))
from src import constants, utils
from src.brokers.constants import Constants
from src._logger import *
from kiteconnect import KiteConnect
import re

file_path = get_path("common/instruments_data/{}_{}.json")

FUT, PE, CE, EQ = "FUT", "PE", "CE", "EQ"
INSTRUMENT_TYPES = [FUT, PE, CE]
EXPIRY_DATE_REGEX = r'(\w*)(0[1-9]|1[0-9]|2[0-9]|3[0-1])(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC|])(\w*)'
EXPIRY_DATE_PATTERN = re.compile(EXPIRY_DATE_REGEX)


def refresh_datastore(exchange):
    """refreshes the datastore"""
    final_data = {}
    log_debug("Fetching instruments data for {}".format(exchange))
    instruments_data = KiteConnect("").instruments(get_exchange(exchange))
    for data in instruments_data:
        stock = get_stock_name_from_trading_symbol(data['tradingsymbol'])
        inst_type = data["instrument_type"]

        if inst_type not in final_data:
            final_data[inst_type] = {"data": {}, "relations": {}}

        if stock not in final_data[inst_type]["relations"]:
            final_data[inst_type]["relations"][stock] = []

        final_data[inst_type]["data"][data['tradingsymbol']] = data
        final_data[inst_type]["relations"][stock].append(data['tradingsymbol'])
    # print final_data
    if FUT in final_data:
        for stock in final_data['FUT']["relations"].iterkeys():
            final_data['FUT']["relations"][stock].sort(key=lambda ele: final_data['FUT']["data"][ele]['expiry'])

    for inst_type, data in final_data.iteritems():
        utils.write_to_json_file(data, file_path.format(exchange, inst_type))


def get_stock_name_from_trading_symbol(trading_symbol):
    matches = EXPIRY_DATE_PATTERN.findall(trading_symbol)
    matches = matches[0] if matches else matches
    if matches:
        return matches[0]
    # dates = ["19", "20", "21", "22", "23", "24", "25"]
    # for date in dates:
    #     if trading_symbol.find(date) > -1:
    #         return trading_symbol.split(date)[0]


JSON_DATA = {}


def load_from_datastore(exchange, segment, symbols):
    if not isinstance(symbols, list):
        symbols = [symbols]
    need_to_load = False
    key = get_data_key(exchange, segment)

    if key not in JSON_DATA:
        need_to_load = True
        JSON_DATA[key] = {"data": {}, "relations": {}}
    else:
        for symbol in symbols:
            if symbol not in JSON_DATA[key]["data"] and symbol not in JSON_DATA[key]["relations"]:
                need_to_load = True
                break

    if need_to_load:
        log_debug('Loading instruments data for {} - {}: {}'.format(exchange, segment, ",".join(symbols)))
        with open(file_path.format(exchange, segment)) as f:
            all_data = json.load(f)
            for symbol in symbols:
                if symbol in all_data["data"]:
                    JSON_DATA[key]["data"][symbol] = all_data["data"].get(symbol, {})
                if symbol in all_data["relations"]:
                    JSON_DATA[key]["relations"][symbol] = all_data["relations"].get(symbol, [])


def get_data_key(exchange, segment):
    return "{}:{}".format(exchange, segment)


def get_exchange(exchange):
    return {
        Constants.Exchange.NSE: KiteConnect.EXCHANGE_NSE,
        Constants.Exchange.BSE: KiteConnect.EXCHANGE_BSE,
        Constants.Exchange.NFO: KiteConnect.EXCHANGE_NFO,
        Constants.Exchange.BFO: KiteConnect.EXCHANGE_BFO,
        Constants.Exchange.MCX: KiteConnect.EXCHANGE_MCX,
        Constants.Exchange.CDS: KiteConnect.EXCHANGE_CDS
    }[exchange]


def get_current_fut_inst(exchange, symbol, expiry_range=3):
    key = get_data_key(exchange, 'FUT')
    load_from_datastore(exchange, 'FUT', symbol)

    futures = JSON_DATA.get(key, {}).get(symbol, [])
    i = 0
    curr_fut = None
    while i < len(futures):
        curr_fut = futures[i]
        if curr_fut:
            expiry_days_left = utils.date_diff(curr_fut['expiry'])
            if expiry_days_left <= expiry_range:
                i += 1
            else:
                break
        else:
            break
    return curr_fut


def get_eq_inst_token(exchange, symbol):  # TODO
    key = get_data_key(exchange, 'EQ')
    load_from_datastore(exchange, 'EQ', symbol)
    futures = JSON_DATA.get(key, {}).get(symbol, [])


# def get_available_futures(exchange):
#     key = get_data_key(exchange, 'FUT')
#     if key not in JSON_DATA:
#         load_from_datastore(exchange, 'FUT')
#     return JSON_DATA.get(key, {}).keys()


def get_current_fut_lot_size(exchange, symbol, expiry_range=3):
    curr_fut = get_current_fut_inst(exchange, symbol, expiry_range)
    return utils.parse_int(curr_fut.get('lot_size', 0), 0)


def get_current_fut_symbol(exchange, symbol, expiry_range=3):
    curr_fut = get_current_fut_inst(exchange, symbol, expiry_range)
    return utils.parse_str(curr_fut.get('tradingsymbol', ''), '')


def get_current_fut_instrument_token(exchange, symbol, expiry_range=3):
    curr_fut = get_current_fut_inst(exchange, symbol, expiry_range)
    if curr_fut:
        return curr_fut.get('instrument_token')
    else:
        return None


def get_instrument(exchange, symbol):
    if exchange == constants.Exchange.NSE or exchange == constants.Exchange.BSE:
        segment = EQ
    elif exchange in [constants.Exchange.NFO, constants.Exchange.MCX, constants.Exchange.CDS]:
        segment = get_segment_from_symbol(symbol)
    if segment:
        key = get_data_key(exchange, segment)
        load_from_datastore(exchange, segment, symbol)
        return JSON_DATA[key]["data"][symbol]


def get_lot_size(exchange, symbol):
    return utils.parse_int(get_instrument(exchange, symbol).get('lot_size', 0), 0)


def get_segment_from_symbol(symbol):
    for segment in INSTRUMENT_TYPES:
        if symbol.endswith(segment):
            return segment
    return EQ


def refresh_all_datastore():
    for exch in [constants.Exchange.NFO,
                 constants.Exchange.MCX,
                 constants.Exchange.NSE,
                 constants.Exchange.CDS,
                 constants.Exchange.BSE]:
        try:
            refresh_datastore(exch)
            import time
            time.sleep(5)
        except:
            log_exception("refresh_datastore failed for {}".format(exch))


if __name__ == "__main__":
    refresh_all_datastore()
    # print get_instrument_token("NSE", "INFY")
    # print get_instrument_token("MCX", "CRUDEOILM19NOVFUT")
    # print get_instrument_token("NFO", "NIFTYIT19OCTFUT")
    # print get_instrument_token("NFO", "NIFTY19OCTFUT")
    # print "\n".join(get_available_futures('MCX'))
    # print get_available_futures('NFO')
    # print "---------------------------"
    # print get_current_fut_symbol(constants.Exchange.NFO, 'INFY')
    # print get_current_fut_symbol(constants.Exchange.MCX, 'LEADMINI')
    # print get_current_fut_symbol(constants.Exchange.MCX, 'GOLD')
