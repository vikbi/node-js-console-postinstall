__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

PROD, LOCAL, LOCAL_REDIS = 'p', 'l', 'lredis'
REDIS_PASS_ENABLE = True
ENV = LOCAL
