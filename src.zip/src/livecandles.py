import os
import sys
from datetime import datetime

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from src._logger import *
from src import scheduler, utils, clients, mysqlDatastore, tick_processor
from src.common import instruments

__author__ = "pryrnjn"
__email__ = "prprakash23@gmail.com"

__subs_list = set()
__ws = None
kws = None
is_last_tick = {
    'MCX': False,
    'CDS': False,
    'default': False
}


def on_ticks(ws, ticks):
    try:
        # Callback to receive ticks.
        for tick in ticks:
            try:
                tick_processor.process_tick(tick, is_last_tick)
            except:
                log_exception('{}: Processing tick for {} failed.'.format('livecandles', inst_token))
    except:
        log_exception_to_telegram('{}: Processing a tick failed.'.format('livecandles'))


def on_connect(ws, response):
    # Callback on successful connect.
    # Subscribe to a list of instrument_tokens (RELIANCE and ACC here).
    global __ws
    __ws = ws
    subscribe(list(__subs_list))
    # print response


def on_close(ws, code, reason):
    if 'forbidden' in str(reason).lower():
        log_error(reason)
        shut_down_ticker()


def shut_down_ticker():
    log_debug("livecandles ticker shutting down")
    kws.close()
    # cleanup_redis(__subs_list)
    log_to_telegram('livecandles ticker shut down!')


def subscribe(subscriptions, mode=None):
    if subscriptions:
        mode = mode or kws.MODE_QUOTE
        for subs in subscriptions:
            __subs_list.add(subs)
        if __ws:
            try:
                __ws.subscribe(subscriptions)
                __ws.set_mode(mode, subscriptions)
            except:
                log_exception("Failed to subscribe {}".format(subscriptions))


def unsubscribe(unsubscriptions, instrument_kind='default'):
    if unsubscriptions:
        for subs in unsubscriptions:
            try:
                __subs_list.remove(subs)
            except:
                log_exception("Failed to remove {} from __subs_list".format(unsubscriptions))

        if __ws:
            try:
                __ws.unsubscribe(unsubscriptions)
            except:
                log_exception("Failed to unsubscribe {}".format(unsubscriptions))
    if not is_last_tick.get(instrument_kind, False):
        is_last_tick[instrument_kind] = True


def on_order_update(ws, order):
    log_debug('Update received {}'.format(order))


def connect(threaded=False):
    kws.connect(threaded=threaded)


if __name__ == "__main__":
    args = sys.argv[1:]
    input_path = args[0] if args else "_.csv"
    H, M, S = config.LIVECANDLES_START_TIME
    H1, M1, S1 = config.LIVECANDLES_END_TIME
    try:
        log_debug('crudeoil livecandles log me!')
        log_to_telegram('CRUDEOIL livecandles are up')

        if utils.is_holiday(datetime.now()):
            raise ValueError('It\'s a holiday!')

        mysqlDatastore.ensure_db()
        
        # global kws
        kws = clients.get_default_client_kws()

        #
        # reading stock names
        psar_settings = mysqlDatastore.get_psar_settings()
        time1_instruments = set()
        time2_instruments = set()
        time3_instruments = set()
        for psar_setting in psar_settings:
            try:
                instrument = instruments.get_instrument(psar_setting.exchange, psar_setting.symbol)
                #print(instrument)
                inst_token = instrument["instrument_token"]
                symbol = ":".join([psar_setting.exchange, psar_setting.symbol])
                log_debug("{} - {}".format(inst_token, symbol))
                tick_processor.update_symbol_by_instrument(inst_token, symbol)
                tick_processor.update_timeframe_subscription(symbol, psar_setting.timeframe)
                if psar_setting.exchange == "CDS":
                    time3_instruments.add(inst_token)
                elif psar_setting.exchange == "MCX":
                    time2_instruments.add(inst_token)
                else:
                    time1_instruments.add(inst_token)
            except:
                #print('iin livecandles')
                log_exception("Failed in getting instrument details {}".format(psar_setting))

        bsq_settings = mysqlDatastore.get_bsq_settings()
        for bsq_setting in bsq_settings:
            try:
                instrument = instruments.get_instrument(bsq_setting.exchange, bsq_setting.symbol)
                inst_token = instrument["instrument_token"]
                symbol = ":".join([bsq_setting.exchange, bsq_setting.symbol])
                log_debug("{} - {}".format(inst_token, symbol))
                tick_processor.update_symbol_by_instrument(inst_token, symbol)
                tick_processor.update_bsq_subscription(symbol, bsq_setting)
                if bsq_setting.exchange == "CDS":
                    time3_instruments.add(inst_token)
                elif bsq_setting.exchange == "MCX":
                    time2_instruments.add(inst_token)
                else:
                    time1_instruments.add(inst_token)
            except:
                log_exception("Failed in getting instrument details {}".format(bsq_setting))
        print('live')
        # Assign the callbacks.
        kws.on_ticks = on_ticks
        kws.on_connect = on_connect
        kws.on_close = on_close

        scheduler.schedule(H, M, S, 1, connect, [True])

        scheduler.schedule(9, 15, 00, 1, subscribe, [time1_instruments])
        scheduler.schedule(15, 30, 00, 1, unsubscribe, [time1_instruments, 'default'])

        scheduler.schedule(9, 00, 00, 1, subscribe, [time2_instruments])
        scheduler.schedule(23, 55, 00, 1, unsubscribe, [time2_instruments, 'MCX'])

        scheduler.schedule(9, 00, 00, 1, subscribe, [time3_instruments])
        scheduler.schedule(17, 00, 00, 1, unsubscribe, [time3_instruments, 'CDS'])

        scheduler.schedule(H1, M1, S1, 1, shut_down_ticker, [])
        scheduler.schedule(H1, M1, S1, 5, scheduler.clear_scheduler, [])
        scheduler.go_ahead_scheduler()

        log_to_telegram('CRUDEOIL, livecandles are extinguishing for today!')
    except:
        scheduler.clear_scheduler()
        log_exception_to_telegram('CRUDEOIL, livecandles extinguished prematurely :(')
