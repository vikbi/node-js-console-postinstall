import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from src import mysqlDatastore
from src._logger import *

__author__ = "pryrnjn"

if __name__ == "__main__":
    log_debug("starting the kite token transfer")
    mysqlDatastore.save_token_from_kite_token()
    log_debug("the kite token transfer completed")
