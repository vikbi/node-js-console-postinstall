import sched
import time

__author__ = "pryrnjn"
from src import DATETIME_FORMAT
from src._logger import log_debug

__scheduler = sched.scheduler(time.time, time.sleep)
__events_scheduled = []


def schedule(h, m, s, priority, func, arguments):
    event = __scheduler.enterabs(get_time(h, m, s), priority, func, arguments)
    __events_scheduled.append(event)


def schedule_at_delay(delay, priority, func, arguments):
    """
    :param delay: In seconds
    :param priority:
    :param func:
    :param arguments: list of arguments
    :return:
    """
    event = __scheduler.enter(delay, priority, func, arguments)
    __events_scheduled.append(event)


def schedule_by_datetime(dt, priority, func, arguments):
    event = __scheduler.enterabs(get_time_from_datetime(dt), priority, func, arguments)
    __events_scheduled.append(event)


def clear_scheduler():
    log_debug("clearing scheduler!!")
    while __events_scheduled:
        try:
            __scheduler.cancel(__events_scheduled.pop())
        except:
            pass


def is_scheduler_empty():
    return __scheduler.empty()


tm_year, tm_mon, tm_mday, tm_wday, tm_yday, tm_isdst = time.localtime().tm_year, time.localtime().tm_mon, time.localtime().tm_mday, time.localtime().tm_wday, time.localtime().tm_yday, -1


def get_time(h, m, s):
    return time.mktime((tm_year, tm_mon, tm_mday, h, m, s, tm_wday, tm_yday, tm_isdst))


def get_time_from_datetime(dt, dt_format=DATETIME_FORMAT):
    return time.mktime(time.strptime(dt.strftime(dt_format), dt_format))


def go_ahead_scheduler():
    if is_scheduler_empty():
        log_debug('Scheduler: Needn\'t wait, Nothing to be scheduled!')
    else:
        __scheduler.run()  # blocking call


if __name__ == '__main__':
    schedule_at_delay(10, 1, log_debug, ("2",))
    import threading
    threading.Thread(target=go_ahead_scheduler).start()
    log_debug("thread nikal gaya")
    go_ahead_scheduler()
    log_debug("thread fir nikal gaya")
