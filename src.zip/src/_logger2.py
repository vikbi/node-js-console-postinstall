import errno
import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler
from shutil import copyfile

import telegram
from telegram.error import NetworkError

from src import get_path, join_path, config

__author__ = "pryrnjn"

# FORMAT = '%(asctime)-15s - %(levelname)s - %(module)s: %(message)s'
# log_file_path = get_path("../logs/alt_%s.log" % TODAY)
# print log_file_path
# logging.basicConfig(format=FORMAT, level=logging.DEBUG)
# _logger = logging.getLogger(__name__)

logname = join_path(config.LOG_HOME_PATH, "debug.log")
handler = TimedRotatingFileHandler(logname, when="midnight", interval=1)
handler.suffix = "%Y%m%d"
handler.setFormatter(logging.Formatter('%(asctime)-15s - %(levelname)s - %(module)s: %(message)s'))
_logger = logging.getLogger(__name__)
_logger.addHandler(handler)
_logger.setLevel(logging.DEBUG)

__existing_loggers = set()


def set_logger(name):
    pass


bot = telegram.Bot(token=config.TELEGRAM_BOT_TOKEN)
CHAT_ID = config.TELEGRAM_CHANNEL_CHAT_ID
TELEGRAM_PREFIX = None


# just logs to log file with level DEBUG
def log_debug2(msg, *args, **kwargs):
    # msg = "%s: %s" % (TAG, msg)
    _logger.debug(msg, *args, **kwargs)
    # log_to_telegram(msg)


#
# important logs, goes to log file with level INFO along with telegram channel

def start_log(_strategy, _type):
    log_to_telegram('Started %s strategy for %s' % (_type, _strategy))


def exit_log(_strategy, _type):
    log_to_telegram('Exited %s strategy for %s' % (_type, _strategy))


if __name__ == "__main__":
    a = bot.get_updates()
    print(a)
