from src import mysqlDatastore, models
from models import *
import time
from src._logger2 import *
import datetime as dt

class LIVE_SAR:

    def __init__(self):
        self.exchange = 'MCX'
        self.symbol = 'CRUDEOIL20JUNFUT'
        self.counter = 0
        self.a = 0
        self.b = 0
        self.new_psar = 0

    def setup(self, exchange, symbol):
        self.exchange = exchange
        self.symbol = symbol

    def get_data(self, timeframe):
        #time.sleep(1)
	log_debug2('calling get data----- {}'.format(timeframe))
	limit = 5
	if timeframe == "15m":
	    limit = 15
	elif timeframe == "30m":
	    limit = 30
        self.data = mysqlDatastore.get_psar_data(self.exchange, self.symbol, '1m', limit)
        
	log_debug2("1 min psar len : {} :{}".format(len(self.data),self.data[0]))
	ltp_data = mysqlDatastore.get_ltp_data(self.exchange, self.symbol, 1)
        log_debug2('ltp data : {}'.format(ltp_data[0])) 
        if len(ltp_data) < 1:
            return
        self.ltp = float(ltp_data[0].ltp)
        psar_data = mysqlDatastore.get_psar_data(self.exchange, self.symbol, timeframe, 1)
        self.psar_data = psar_data[0]
	log_debug2("{} psar:{}".format(timeframe, self.psar_data))
	
        configdata = mysqlDatastore.get_config_data(timeframe, self.symbol)
	log_debug2("prev config : timeframe : {} {} ".format(timeframe,configdata))        

	log_debug2('----------------------')
	self.a = configdata.a
        self.b = configdata.b
        self.counter = configdata.counter
        self.ep = configdata.ep
        self.config_id = configdata.id
        self.new_psar = configdata.psar
        self.new_trend = configdata.trend
        self.old_psar = configdata.old_psar
        self.old_trend = configdata.old_trend
        self.k1 = configdata.k1

    def initial(self, timeframe):
        self.counter = 0
        self.a = 0
        self.b = 0
	log_debug2('calling initial : {} '.format(timeframe))
        psar_data = mysqlDatastore.get_psar_data(self.exchange, self.symbol, timeframe, 1)
	log_debug2("initial psar data {} ".format(psar_data[0]))        

        if len(psar_data) < 1:
            return
        self.trend = psar_data[0].trend
        self.ep = round(psar_data[0].ep, 2)
        self.k1 = float(float(self.ep) - float(psar_data[0].psar)) * float(psar_data[0].acc)
        self.old_psar = float(round(psar_data[0].psar, 2))
        self.old_trend = psar_data[0].trend

    def calculate(self, timeframe, counter):
        self.get_data(timeframe)
        if len(self.data) < 1:
            return
	today = dt.datetime.now()
	minutes = today.strftime('%M')
	if((int(minutes) % int(counter)) == 1):
	    log_debug2('resetting timeframe {} : {}'.format(timeframe ,today))
	    self.initial(timeframe)
        elif(self.counter == 0):
            self.initial(timeframe)
            
        if self.counter < counter:
            self.counter += 1
        else:
            self.initial(timeframe)

        high, low = self.get_high_low(self.ltp)
        
        if self.a != 1 and self.b != 1:
            self.new_psar = round((self.old_psar + self.k1), 2)
            self.new_trend = self.old_trend
        elif self.a == 1 or self.b == 1:
            self.new_psar = self.new_psar
            self.new_trend = self.new_trend

        if (self.old_trend == 1) & (low <= self.new_psar) & (self.a != 1) & (self.b != 1):
            self.new_trend = 0
            self.new_psar = self.ep
            self.a = 1
        elif (self.old_trend == 0) & (high >= self.new_psar) & (self.b != 1) & (self.a != 1):
            self.new_trend = 1
            self.new_psar = self.ep
            self.b = 1
	log_debug2('new config timeframe : {}, high: {}, low : {}, a : {}, b:{}, ep: {}, k1:{}'.format(timeframe, high,low, self.a, self.b, self.ep, self.k1)) 

    def get_high_low(self, ltp):
        high = self.data[0].high
        low = self.data[0].low
        for data in self.data:
            if data.high > high:
                high = data.high
            if data.low < low:
                low = data.low

        high = round(high, 2)
        low = round(low, 2)
        current_ltp = ltp
        if current_ltp > high:
            high = current_ltp
        if current_ltp < low:
            low = current_ltp

        return high, low

    def save_config(self):
        mysqlDatastore.update_config_data(self.counter, self.a, self.b, self.new_trend, self.ep, self.new_psar, self.old_trend, self.old_psar, self.k1, self.config_id)

    def live_sar(self, exchange, symbol):
        self.exchange = exchange
        self.symbol = symbol
        #print('call')
        self.calculate('5m', 5)
        #print('5min_sar', self.new_psar)
        if self.new_psar == 0:
            return
        self.save_config()
        trend_5 = self.new_trend
        psar_5 = self.new_psar
        self.calculate('15m', 15)
        self.save_config()
        trend_15 = self.new_trend
        psar_15 = self.new_psar
        self.calculate('30m', 30)
        self.save_config()
        trend_30 = self.new_trend
        psar_30 = self.new_psar

        tradeData = TradeData(None,self.ltp, self.data[0].psar, trend_5, psar_5, trend_15, psar_15, trend_30, psar_30)
        log_debug2("saving trade data :{}".format(tradeData))
	mysqlDatastore.save_trade_data(self.exchange, self.symbol, tradeData)

#import datetime as dt
def main(exchange, symbol):
    import datetime as dt
    
    log_debug2('================in livesar : {}========= '.format(dt.datetime.now()))
    liveSar = LIVE_SAR()
    liveSar.live_sar(exchange, symbol)
    log_debug2('========live sar done====================')
def get_instance():
    return LIVE_SAR()

#if __name__ == '__main__':
#    print('yup call--')
