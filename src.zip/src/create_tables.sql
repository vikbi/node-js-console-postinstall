CREATE DATABASE IF NOT EXISTS `{db_name}`;
USE `{db_name}`;

CREATE TABLE IF NOT EXISTS `broker_token` (
  `client_id` varchar(10) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `symbols` (
  `exchange` varchar(5) NOT NULL,
  `symbol` varchar(50) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exchange`, `symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `psar_settings` (
  `title` varchar(100) DEFAULT NULL,
  `exchange` varchar(5) NOT NULL,
  `symbol` varchar(50) NOT NULL,
  `timeframe` varchar(5) NOT NULL,
  `min_acc` decimal(7,3) DEFAULT NULL,
  `max_acc` decimal(7,3) DEFAULT NULL,
  `acc` decimal(7,3) DEFAULT NULL,
  `dacc` decimal(7,3) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exchange`, `symbol`, `timeframe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `buy_sell_qty_settings` (
  `title` varchar(100) DEFAULT NULL,
  `exchange` varchar(5) NOT NULL,
  `symbol` varchar(50) NOT NULL,
  `timeframe` varchar(5) NOT NULL,
  `diff_threshold` decimal(7,3) DEFAULT NULL,
  `order_type` varchar(5) NOT NULL,
  `order_quantity` int NOT NULL,
  `sl` decimal(7,3) DEFAULT NULL,
  `target` decimal(7,3) DEFAULT NULL,
  `tsl` decimal(7,3) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exchange`, `symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


