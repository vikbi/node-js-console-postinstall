# -*- coding: utf-8 -*-
"""
Created on Tue June 11 04:49:03 2020
@author: Vivek Chaudhari
"""
import datetime as dt
from src import mysqlDatastore, models, constants, clients
from src._logger import *
import requests
from src._logger2 import *
import json
# __broker = clients.get_broker("BL8240")

class TRADE:
    __instance = None
	
    @staticmethod
    def getInstance():
        """ Static access method. """
        if TRADE.__instance == None:
            TRADE()
        return TRADE.__instance

    def __init__(self):
        if TRADE.__instance != None:
            raise Exception("This class is a singleton!")
        else:
            TRADE.__instance = self

        self.reset()
        self.exchange = ''
        self.symbol = ''

    def clear_cache(self):
        self.reset()
        # self.all_profit = 0
        self.exit_time = '23:27'
        self.day = 1
        self.startfile = ''
        self.all_profit = 0
        self.notify = False
        self.response = ''
        self.place_order_type = ''
        self.dbtext = ''
        self.logtext = ''
        self.place_order = False
        self.notify_profit = 0

    def verify_keys(self, exchange, symbol):
        keyData = mysqlDatastore.get_keys_data(exchange, symbol)
        stored_keys = []
        for kd in keyData:
            stored_keys.append(kd[0])
        inserts = {}
        for ck in constants.CONFIG_KEYS:
            if ck not in stored_keys:
                inserts[ck] = '0'
        
        if len(inserts) > 0:
            mysqlDatastore.save_keys_data(inserts)
    
    def reset(self):
        self.trend_15 = 10
        self.trend_30 = 10
        self.prev_trend_15 = 10
        self.prev_trend_30 = 10
        self.current_ltp = 0
        self.order_ltp = 0
        
        self.eb = 0
        self.es = 0
        self.high = 0
        self.low = 0
        self.trade = 0
        self.trade_es = 0
        self.order_time = 0
        self.tt = 0
        self.bp1 = 0
        self.m1 = 0
        self.bu = 0
        self.bb = 0
        self.sp1 = 0
        self.m2 = 0
        self.sds = 0
        self.duck1 = 0
        self.duck2 = 0
        self.se = 0
        
        self.order_index = 0
        self.ttt = 0
        
        self.total_profit = 0

        self.bhigh = 0
        # self.blow = 0
        self.shigh = 0
        self.slow = 0
        self.np3 = 0
        self.order_type = None
        self.place_order_type = None
        self.temp_order = []
        self.notify_profit = 0

        self.alert = 0
        self.alert2 = 0
        self.alert3 = 0
        self.alert4 = 0
        self.alert5 = 0
        self.alert6 = 0

    def get_keys(self):
        keyData = mysqlDatastore.get_keys_data()
        keys = {}
        for kd in keyData:
            if kd[0] in constants.CONFIG_KEYS:
                if kd[0] in constants.CONFIG_KEYS_NOTINT:
                    keys[kd[0]] = kd[1]
                else:
                    keys[kd[0]] = int(kd[1])
        return keys

    def loader(self, currentLtpData, prevLtpData, temp_data):
        log_debug2('loading..{}, prev : {}, temp: {} '.format(currentLtpData, len(prevLtpData), len(temp_data)))
        try:
            self.trade_id = currentLtpData.id
            prof_arr = []
            try:
                for i in range(len(prevLtpData) - 1):
                    if i < (len(prevLtpData) - 1):
                        profit = float(prevLtpData[i].ltp) - float(prevLtpData[i+1].ltp)
                        prof_arr.append(profit)	
            except:
                log_debug2('error in profit arr')
            
            temp15_data = []
            if len(temp_data)>=15:
                for data in temp_data:
                    highlow = [float(data.high), float(data.low)]
                    temp15_data.append(highlow)

            requestData = {}
            requestData['keys'] = self.get_keys() 
            requestData['trend_15'] = currentLtpData.trend_15
            requestData['trend_30'] = currentLtpData.trend_30
            requestData['prev_trend_15'] = prevLtpData[1].trend_15
            requestData['prev_trend_30'] = prevLtpData[1].trend_30
            requestData['current_ltp'] = currentLtpData.ltp
            requestData['prev_minute_ltp'] = prevLtpData[1].ltp
            requestData['current_psar'] = currentLtpData.psar_5
            requestData['current_time'] = currentLtpData.created_at.strftime('%m/%d/%Y %H:%M')
            requestData['current_index'] = currentLtpData.id
            requestData['all_profit_arr'] = prof_arr[::-1]
            requestData['temp15_data'] = temp15_data
            requestData['prev_prev_min_ltp'] = prevLtpData[2].ltp
            requestData['prev_min_psar'] = prevLtpData[1].psar_5
            requestData['exchange'] = self.exchange
            requestData['symbol'] = self.symbol

            return requestData
        except ValueError:
            log_debug('error load request data')
            return

    def minusMinute(self, time, minute):
        # fulldate = dt.datetime.fromisoformat(str(time))
        fulldate = time - dt.timedelta(minutes=minute)
        iso = fulldate.isoformat()
        split = iso.split('T')
        return split[0] + ' ' + split[1]

    def process_log(self, log):
        logs = log.json()
        if len(logs) > 4:
            mysqlDatastore.save_keys_data(logs['keys'])
            dbtext = logs['dbtext']
            order_type = logs['keys']['order_type']
            profit = logs['keys']['notify_profit']
            mysqlDatastore.save_trade_profit(self.exchange, self.symbol, self.trade_id, dbtext, profit, order_type)
            log_debug2('log updated..')
            if logs['notify']:
                log_debug2('notifying..')
                logtext = logs['logtext']
                log_to_telegram(logtext)
                log_debug2('alert sent...')
                try:
                    self.execute_order(logs)
                    log_debug2('order executed..')
                except:
                    log_debug2('error in order execution')

    def log(self, logData):
        import time
        start = time.time()
        path = mysqlDatastore.get_keys_data('log')
        try:
            log_debug2('logging 1...')
            log = requests.post(url=path[0][1], json=logData)
        except:
            log_debug2('logging 2...')
            log = requests.post(url=path[0][1], json=logData)
        log_debug2("logged.. {} :{}".format(logData, log.json()))
        log_debug2('required.. {}'.format(str(time.time() - start)))
        self.process_log(log)

    def trade_call(self, exchange, symbol):
        self.exchange = exchange
        self.symbol = symbol
        temp_time = '09:15'
        tempData = []
        tradeData = mysqlDatastore.get_trade_data(self.exchange, self.symbol)
        # print(tradeData)
        fulltime = tradeData[0].created_at
        start_time = self.minusMinute(fulltime,29)
        end_time = fulltime
        temp_data = mysqlDatastore.get_psar_data_from(self.exchange, self.symbol, '1m', start_time, end_time)
        tempData = temp_data[::-1]
        check = fulltime.strftime('%H:%M')
        if check == temp_time:
            start_time = self.minusMinute(fulltime, 14)
            end_time = fulltime
            temp_data = mysqlDatastore.get_psar_data_from(self.exchange, self.symbol,'1m', start_time, end_time)
            tempData = temp_data[::-1]
        log_debug2('data reader...')
        log = self.loader(tradeData[0], tradeData, tempData)
        log_debug2('data loader...')
        self.log(log)

    def execute_order(self, info):
        log_debug2('in execution')
        order = {}
        order['exchange'] = self.exchange
        order['symbol'] = self.symbol
        order['quantity'] = 1
        order['sl'] = None
        order['tsl'] = None
        order['tag'] = "bsq"
        # broker = clients.get_broker("UR8440")
        for data in info['order']:
            current_time = dt.datetime.strptime(info['current_time'],'%m/%d/%Y %H:%M')
            order_data = [data['ltp'], data['type'], current_time]
            order_id = mysqlDatastore.save_order_data(order_data)
            order['price'] = data['ltp']
            order['target'] = data['ltp']
            order['transaction_type'] = data['type']
        log_debug2('place order : {}'.format(order))
        status = 1 #broker.place_order(order)
        log_debug2('order executed : success {}'.format(status))
        if status:
            today = dt.datetime.now()
            last_sent = today.strftime('%Y-%m-%d %H:%M:%S')
            order['last_sent'] = last_sent
            order['status'] = 1
            mysqlDatastore.update_order_data(order_id, order)

    def process_response(self):
        logs = "{u'current_time': u'05/28/2020 10:44', u'logtext': u'----------------------------\nTime : 05/28/2020 10:44\n---------------------------\nEXIT MCX CRUDE BUY ORDER at 2417\nPROFIT : Rs1100\n\n----------------------------\nTime : 05/28/2020 10:44\n---------------------------\nPlace MCX CRUDE SELL ORDER at 2417', u'keys': {u'max_loss': 0, u'trade': 2, u'high': 2419, u'min_loss': 0, u'b1': 0, u'b3': 1, u'ttt': 0, u'es': 0, u'blow': 0, u'slow': 2417, u'bb': 0, u'm3': 0, u'tt': 0, u'bp1': 0, u'order_ltp': 2417, u'low': 2417, u'shigh': 2417, u'm2': 0, u'm1': 0, u'notify_profit': 0, u'order_time': u'0', u'sds': 0, u'trade_es': 0, u'duck1': 0, u'duck2': 0, u'alert': 0, u'bt': 0, u'bu': 0, u'order_index': 1760, u'np3': 0, u'eb': 0, u'order_type': u'SELL', u'sp1': 0, u'total_profit': 9, u'prev_prev_min_ltp': 2419, u'bhigh': 2419, u'alert2': 0, u'alert3': 0, u'alert4': 0, u'alert5': 0, u'alert6': 0, u'prev_order_type': u'SELL', u's1': 0, u'se': 0}, u'place_order': True, u'notify': True, u'order': [{u'symbol': u'CRUDEOIL', u'ltp': 2417, u'type': u'SELL', u'quantity': 1}, {u'symbol': u'CRUDEOIL', u'ltp': 2417, u'type': u'SELL', u'quantity': 1}], u'dbtext': u'2417:05/28/2020 10:44 buy trade reverse exit continue in sell = 11\n\n2417:05/28/2020 10:44 sell order\n'}"
        logs = logs.replace("u'", "\"")
        logs = logs.replace("\'", "\"")
        logs = logs.replace("\n", " ")
        logs = logs.replace("True", "\"True\"")
        import json
        logs = json.loads(logs)
        self.exchange = "MCX"
        self.symbol = "CRUDEOIL20JUNFUT"
        self.execute_order(logs)

    def local_test2(self):
        self.exchange = "MCX"
        self.symbol = "CRUDEOIL20JUNFUT"
        tradeData = mysqlDatastore.local_get_trade_data(self.exchange, self.symbol)
        last_index = len(tradeData)
        start_index = 30
        for i in range(start_index, last_index):
            temp_time = '09:15'
            fulltime = tradeData[i].created_at
            print(fulltime)
            start_time = self.minusMinute(fulltime,29)
            end_time = fulltime
            temp_data = mysqlDatastore.get_psar_data_from(self.exchange, self.symbol, '1m', start_time, end_time)
            tempData = temp_data[::-1]
            check = fulltime.strftime('%H:%M')
            if check == temp_time:
                start_time = self.minusMinute(fulltime, 14)
                end_time = fulltime
                temp_data = mysqlDatastore.get_psar_data_from(self.exchange, self.symbol,'1m', start_time, end_time)
                tempData = temp_data[::-1]
            currentLtpData = tradeData[start_index]
            prevLtpData = tradeData[start_index-7: start_index]
            prevLtpData = prevLtpData[::-1]
            data = self.loader(currentLtpData, prevLtpData,  tempData)
            self.log(data)
            start_index+=1


def main(exchange, symbol):
    log_debug2('================call from trade=============')
    print('in main trade')
    trade = TRADE.getInstance()
    trade.trade_call(exchange,  symbol)
    log_debug2('###############-trade end-###################')

def get_instance():
    return TRADE.getInstance()
   
